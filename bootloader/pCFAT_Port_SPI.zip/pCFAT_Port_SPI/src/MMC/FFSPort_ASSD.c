/***********************************************************
*  ASSD/McEx driver as hock-up onto the free FFS/FAT Port  *
*             to MMC/SD-slot using SPI-mode                *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                     FFSPort_ASSD.c                       *
*     ASSD/McEx interface for FFS/FAT to MMC(SPI) PORT     *
************************************************************
*      - code generation McEx       Frank Goetze   04/2010 *
*      - renamed and add            Frank Goetze   08/2012 *
*        ASSD 2.0 detection                                *
*                                                          *
***********************************************************/
#include "../../inc/MMC/FFS_Port_MMC.h"

#define ASSD_PSI_SR             0
#define ASSD_PSI_PR             4 
#define ASSD_SEC_SYSTEM         1
#define ASSD_CONTROL_RESET      1 

#define ASSD_SR_STATE_IDLE      0
#define ASSD_SR_STATE_INPROC    1
#define ASSD_SR_STATE_COMPLETE  2
#define ASSD_SR_STATE_ABORTED   3 

/************* externals from FFS_Port_MMC ****************/
//lint -esym(526,MMCWriteCMD) -esym(526,MMCReadBlock) -esym(526,FFS_values) -esym(526,FFSp_data) -esym(526,FFSp_ver) -esym(526,MMC_uSpeed) -esym(526,MMC_Nac) -esym(526,MMC_Nbs)
extern U08       MMCWriteCMD(U08 cmd, U32 arg, U08 end);
extern U08       MMCReadBlock(U08 cmd, U32 arg, U08 *buff, U32 count, U08 creg);
extern FFS_SIZE  FFS_values;
extern U08       FFSp_data[64];
extern U08       FFSp_ver;
extern U32       MMC_uSpeed;
extern U32       MMC_Nac;
extern U32       MMC_Nbs;

/******************* global variables *********************/
static U08       ASSD_ver;                                 // org version value from properties register
static U32       ASSD_Nsrl;                                // time between CMD-R1 & data response on reading, busy time (in 250ms units)
static U32       ASSD_Nswb;                                // time between last command-data at write and ASSD response available (in 250ms units)
static U32       ASSD_Nwsb;                                // time between last command-data at write and CRC-response, busy time (in 250ms units)

/*
************************************************************
*   send/receive data using a McEx/ASSD command (internal)
************************************************************
*/
static U16 ASSDSendReceive(U08 cmd, U32 arg, U08 *buff, U16 len, U16 maxrlen)
{
    U32  i;
    U08  res;

    switch(cmd) {
        case ASSD_CONTROL_SYSTEM:
            res = MMCWriteCMD(ASSD_CONTROL_SYSTEM, arg, 0);    // send control cmd (R1b result)
            while(res == 0x00) res = FFSPort_MMC_Send(0xFF);   // wait while R1b busy (later we will wait Ncb here !)
            FFSPort_MMC_CS_OFF;                            // disable MMC-interface
            break;
        case ASSD_SEND_PSI:
            if(len > maxrlen) len = maxrlen;               // if buffer to small -> cut data receive
            res = MMCWriteCMD(ASSD_SEND_PSI, arg, 0);      // read properties & status information
            if(res == FFS_NO_ERR) {
                i = 0;                                     // wait "Nac"/"Ncx" for startbyte (0xFE)
                while((FFSPort_MMC_Send(0xFF) == 0xFF) && (i < MMC_Nac)) i++;
                if(i < MMC_Nac) {                          // read data and padding
#ifdef USE_MMC_DMA
                    (void)FFSPort_MMC_RxBlock(buff, len);  // on STM32 we cant get any status
                    (void)FFSPort_MMC_RxBlockDummy(FFS_values.sectorsize - len);
#else
                    for(i = 0; i < len; i++) buff[i] = FFSPort_MMC_Send(0xFF);
                    for(; i < FFS_values.sectorsize; i++) (void)FFSPort_MMC_Send(0xFF);
#endif
                    (void)FFSPort_MMC_Send(0xFF); (void)FFSPort_MMC_Send(0xFF);  // read dummy-CRC
                    FFSPort_MMC_CS_OFF;                    // disable MMC-interface
                    return(len);
                }
            }
            FFSPort_MMC_CS_OFF;
            break;
        case ASSD_WRITE_SEC_CMD:
            res = MMCWriteCMD(ASSD_WRITE_SEC_CMD, arg, 0); // send command with cmd-mode & one block
            if(res == FFS_NO_ERR) {
                (void)FFSPort_MMC_Send(0xFF);                    // wait "Nwr" in front of wr-data
                (void)FFSPort_MMC_Send(MMC_STARTBLOCK_MWRITE);   // send startbyte
                (void)FFSPort_MMC_Send((U08)((len + 2) >>  8));  // send STL MSB
                (void)FFSPort_MMC_Send((U08)(len + 2));          // send STL LSB
#ifdef USE_MMC_DMA
                (void)FFSPort_MMC_TxBlock(buff, len);            // on STM32 we can't get any status
                (void)FFSPort_MMC_TxBlockDummy(FFS_values.sectorsize - (len + 2));
#else
                for(i = 0; i < len; i++) (void)FFSPort_MMC_Send(buff[i]);    // send apdu and padding
                for(; i < (FFS_values.sectorsize - 2); i++) (void)FFSPort_MMC_Send(0);
#endif
                (void)FFSPort_MMC_Send(0xFF); (void)FFSPort_MMC_Send(0xFF);  // send dummy-CRC
                res = FFSPort_MMC_Send(0xFF);              // get data-response (no "Nxx")
                switch(res & MMC_DR_MASK) {                // mask data-response code
                    case MMC_DR_ACCEPT:                    // ** data accepted
                        i = 0;                             // wait "Nwsb" while busy
                        while((FFSPort_MMC_Send(0xFF) != 0xFF) && (i < (ASSD_Nwsb)? ASSD_Nwsb : MMC_Nbs)) i++;
                        if(i >= (ASSD_Nwsb)? ASSD_Nwsb : MMC_Nbs) { FFSPort_MMC_CS_OFF; return(0); }
                        FFSPort_MMC_CS_OFF;                // disable MMC-interface
                        return(len);
                    case MMC_DR_REJECT_WRITE_ERROR:        // ** data rejected due to a write error
                    case MMC_DR_REJECT_CRC:                // ** data rejected due to a CRC error
                    default:
                        FFSPort_MMC_CS_OFF;                //    disable MMC-interface
                        return(0);                         //    error
                }
            }
            FFSPort_MMC_CS_OFF;                            // disable MMC-interface
            break;
        case ASSD_READ_SEC_CMD:
            res = MMCWriteCMD(ASSD_READ_SEC_CMD, arg, 0);  // send command with cmd-mode & one block
            if(res == FFS_NO_ERR) {
                i = 0;                                     // wait "Nsrl" for startbyte (0xFE)
                while((FFSPort_MMC_Send(0xFF) == 0xFF) && (i < ASSD_Nsrl)) i++;
                if(i < ASSD_Nsrl) {                        // read len, data and padding
                    res = FFSPort_MMC_Send(0xFF); len = (U16)(res) << 8;
                    res = FFSPort_MMC_Send(0xFF); len |= res; len -= 2;
                    if(len > maxrlen) len = maxrlen;       // if buffer to small -> cut data receive
#ifdef USE_MMC_DMA
                    (void)FFSPort_MMC_RxBlock(buff, len);  // on STM32 we cant get any status
                    (void)FFSPort_MMC_RxBlockDummy(FFS_values.sectorsize - (len + 2));
#else
                    for(i = 0; i < len; i++) buff[i] = FFSPort_MMC_Send(0xFF);
                    for(; i < (FFS_values.sectorsize - 2); i++) (void)FFSPort_MMC_Send(0xFF);
#endif
                    (void)FFSPort_MMC_Send(0xFF); (void)FFSPort_MMC_Send(0xFF);  // read dummy-CRC
                    FFSPort_MMC_CS_OFF;                    // disable MMC-interface
                    return(len);                           // return received length including SW12
                }
            }
            FFSPort_MMC_CS_OFF;
            break;
        default:
            break;
    }
    return(0);
}

/*
************************************************************
*            enable/disable McEx/ASSD mode
************************************************************
*/
U08 FFSPort_ASSD_SetMode(U08 mode)
{
    U32 arg, grp2;
    U08 i;

    ASSD_ver = ASSD_Nsrl = ASSD_Nswb = ASSD_Nwsb = grp2 = 0;
    i = FFSPort_MediaDetect();                             // media present ?
    if(i != FFS_NO_ERR) return(i);                         // not initialized or not a SDxx-card
    if((FFSp_ver & FFSp_MARK_SD)!= FFSp_MARK_SD) return(FFS_PORT_ERR);
    i = 0;
    do {
        if(MMCReadBlock(MMC_SWITCH, 0x00FFFFFF, (U08 *)FFSp_data, 64, 1) != FFS_NO_ERR) return(FFS_PORT_ERR);
        if(!(FFSp_data[11] & 0x12)) return(FFS_PORT_ERR);  // McEx and ASSD mode not supported (supported-bits group no 2)
        arg = 0x80FFFF0F;                                  // grp no 2 = default
        if(mode != 0) {
            if(FFSp_data[11] & 0x10) grp2 = 0x40;          // ASSD 2.0 or higher
            else grp2 = 0x10;                              // McEx 1.0 or 1.1
        }                                                  // switch to mode and check result-status
        if(MMCReadBlock(MMC_SWITCH, arg | grp2, (U08 *)FFSp_data, 64, 1) != FFS_NO_ERR) return(FFS_PORT_ERR);
    } while(((FFSp_data[16] & 0xF0) != grp2) && ((i++) < 0xFE));
    if(i >= 0xFE) return(FFS_PORT_ERR);                    // error on switch
    for(i = 0; i < 0xFF; i++) { _NOP(); _NOP(); _NOP(); }  // wait for resync card-internally (processor-speed depending)
    if(mode != 0) {                                        // read properties (timeouts in clk - without code-cycles)
        if(ASSDSendReceive(ASSD_SEND_PSI, ASSD_PSI_PR, (U08 *)FFSp_data, 32, sizeof(FFSp_data)) == 32) {
            ASSD_ver  = FFSp_data[2];
            ASSD_Nsrl = ((MMC_uSpeed * 25) / 800) * FFSp_data[0];
            ASSD_Nswb = ((MMC_uSpeed * 25) / 800) * FFSp_data[1];
            if(ASSD_ver > 0) ASSD_Nwsb = ((MMC_uSpeed * 25) / 800) * FFSp_data[7];
        } else return(FFS_PORT_ERR);                       // error on read properties
#ifdef FFS_MMC_ADD_INFO
        FFS_values.assd.Type       = grp2;
        FFS_values.assd.SpecVer[1] = '.';                  // collect some informations ...
        FFS_values.assd.SpecVer[2] = '0';                  // ... about the McEx/ASSD sub-system
        FFS_values.assd.SpecVer[3] = '0';
        FFS_values.assd.SpecVer[4] = 0;
        switch(ASSD_ver) {
            case 0:  FFS_values.assd.SpecVer[0] = '1'; break;
            case 1:  FFS_values.assd.SpecVer[0] = '1'; FFS_values.assd.SpecVer[2] = '1'; break;
            case 2:  FFS_values.assd.SpecVer[0] = '2'; break;
            case 3:  FFS_values.assd.SpecVer[0] = '3'; break;
            default: FFS_values.assd.SpecVer[0] = '?'; break;
        }
        FFS_values.assd.Nsrl = ASSD_Nsrl;
        FFS_values.assd.Nswb = ASSD_Nswb;
        if(ASSD_ver > 0) {                                 // values valid only from 1.10 and greater
            FFS_values.assd.CLsupport   = ((U16)FFSp_data[3] << 8) | (FFSp_data[4] & 0xFE);
            FFS_values.assd.PMsupport   = FFSp_data[4] & 0x01;
            FFS_values.assd.Nexr        = ((MMC_uSpeed * 10) / 800) * FFSp_data[5];
            FFS_values.assd.Nexw        = ((MMC_uSpeed * 25) / 800) * FFSp_data[6];
            FFS_values.assd.Nwsb        = ASSD_Nwsb;
            FFS_values.assd.AlgoSupport = ((U16)FFSp_data[8] << 8) | FFSp_data[9];
            FFS_values.assd.EncSupport  = ((U16)FFSp_data[10] << 8) | FFSp_data[11];
            if(ASSD_ver > 1) {                             // values valid only from 2.00 and greater
                FFS_values.assd.SecSys      = ((U16)FFSp_data[12] << 8) | FFSp_data[13];
            } else {
                FFS_values.assd.SecSys      = ((FFSp_data[12] | FFSp_data[13]) == 0)? 0 : -1;
            }
        } else {
            FFS_values.assd.CLsupport   = ((FFSp_data[3] | (FFSp_data[4] & 0xFE)) == 0)? 0 : -1;
            FFS_values.assd.PMsupport   = ((FFSp_data[4] & 0x01) == 0)? 0 : -1;
            FFS_values.assd.Nexr        = (FFSp_data[5] == 0)? 0 : -1;
            FFS_values.assd.Nexw        = (FFSp_data[6] == 0)? 0 : -1;
            FFS_values.assd.Nwsb        = (FFSp_data[7] == 0)? 0 : -1;
            FFS_values.assd.AlgoSupport = ((FFSp_data[8] | FFSp_data[9]) == 0)? 0 : -1;
            FFS_values.assd.EncSupport  = ((FFSp_data[10] | FFSp_data[11]) == 0)? 0 : -1;
            FFS_values.assd.SecSys      = ((FFSp_data[12] | FFSp_data[13]) == 0)? 0 : -1;
        }
#endif
        if(ASSD_ver > 1) {
            if(!(((U16)FFSp_data[12] << 8 | FFSp_data[13]) & (1 << ASSD_SEC_SYSTEM))) return(FFS_PORT_ERR);
            if(ASSDSendReceive(ASSD_SEND_PSI, ASSD_PSI_SR, (U08 *)FFSp_data, 32, sizeof(FFSp_data)) != 32) return(FFS_PORT_ERR);
            if(ASSDSendReceive(ASSD_CONTROL_SYSTEM, (ASSD_SEC_SYSTEM << 8) | ASSD_CONTROL_RESET, NULL, 0, 0) != 0) return(FFS_PORT_ERR);
            if (FFSp_data[6] != ASSD_SEC_SYSTEM) {
                if(ASSDSendReceive(ASSD_SEND_PSI, ASSD_PSI_SR, (U08 *)FFSp_data, 32, sizeof(FFSp_data)) != 32) return(FFS_PORT_ERR);
                if(FFSp_data[6] != ASSD_SEC_SYSTEM) return(FFS_PORT_ERR);
            }
        } else {
            if(ASSDSendReceive(ASSD_CONTROL_SYSTEM, ASSD_CONTROL_RESET, NULL, 0, 0) != 0) return(FFS_PORT_ERR);
        }
    }
    return(FFS_NO_ERR);                                    // no error
}

/*
************************************************************
*            send ADPU and wait for response
************************************************************
*/
U16 FFSPort_ASSD_APDU(U08 *apdu, U16 len, U16 maxrlen)
{
    U32 i;

    if((apdu == NULL) || (len > 510)) return(0);           // invalid pointer or more than one block ?
    if(FFSPort_MediaDetect() != FFS_NO_ERR) return(0);     // media present ?
    if((FFSp_ver & FFSp_MARK_SD) != FFSp_MARK_SD) return(0); // not initialized or not a SDxx-card
                                                           // ****** test TRM status *****
    i = ASSDSendReceive(ASSD_SEND_PSI, ASSD_PSI_SR, (U08 *)FFSp_data, 32, sizeof(FFSp_data));
    if((i != 32) || (FFSp_data[0] != ASSD_SR_STATE_IDLE)) {// TRM not read for next APDU command ?
        (void)ASSDSendReceive(ASSD_CONTROL_SYSTEM, (ASSD_ver > 1)? (ASSD_SEC_SYSTEM << 8) | ASSD_CONTROL_RESET : ASSD_CONTROL_RESET, NULL, 0, 0);
        return(0);                                         // we have still an error, reset and report error
    }                                                      // ****** write APDU-command ******
    if(ASSDSendReceive(ASSD_WRITE_SEC_CMD, 1, (U08 *)apdu, len, 0) != len) return(0);
    i = 0;                                                 // ****** check STATUS ******
    do {
        len = ASSDSendReceive(ASSD_SEND_PSI, ASSD_PSI_SR, (U08 *)FFSp_data, 32, sizeof(FFSp_data)); i++;
    } while((len == 32) && ((FFSp_data[0] == ASSD_SR_STATE_INPROC)) && (i < ASSD_Nswb));
    if(FFSp_data[0] != ASSD_SR_STATE_COMPLETE) {           // TRM not normal finish APDU command ?
        (void)ASSDSendReceive(ASSD_CONTROL_SYSTEM, (ASSD_ver > 1)? (ASSD_SEC_SYSTEM << 8) | ASSD_CONTROL_RESET : ASSD_CONTROL_RESET, NULL, 0, 0);
        return(0);                                         // we have still an error, reset and report error
    }
    if((len != 32) || (i >= ASSD_Nswb)) return(0);         // ****** read APDU-response ******
    len = ASSDSendReceive(ASSD_READ_SEC_CMD, 1, (U08 *)&apdu[2], 0, maxrlen);
    apdu[0] = len >> 8; apdu[1] = len & 0xFF;
    return(len + 2);
}

/*
************************************************************
*          reset secure device via McEx interface
************************************************************
*/
U16 FFSPort_ASSD_Reset(void)
{
    if(FFSPort_MediaDetect() != FFS_NO_ERR) return(1);       // media present ?
    if((FFSp_ver & FFSp_MARK_SD) != FFSp_MARK_SD) return(2); // not initialized or not a SDxx-card
    return((U16)ASSDSendReceive(ASSD_CONTROL_SYSTEM, (ASSD_ver > 1)? (ASSD_SEC_SYSTEM << 8) | ASSD_CONTROL_RESET : ASSD_CONTROL_RESET, NULL, 0, 0));
}                                                            // reset sec-device

/************************** END ***************************/
