/***********************************************************
*     a FREE MMC/SD-interface to SPI-slot of AT91SAM3Sxx   *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_MMC.c                       *
*                   MMC/SD TO SPI PORT                     *
************************************************************
*      - code generation            Frank Goetze   11/2010 *
***********************************************************/

#include "../../../inc/MMC/AT91SAM3Sxx/FFSPort_SPI.h"

/****************** constant variables ********************/
#define CPU_CRISTAL_CLK  12000000UL                        // processor crystal-clock in Hz

/******************* global variables *********************/
U08 FFSPort_MMC_CDi;                                       // remember a negative MMC-CD interrupt

/*
************************************************************
*          set max possible baudrate and return this
************************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk)
{
    U32 s_clksrc;
    U08 i;

    s_clksrc = CPU_CRISTAL_CLK;                                        // set start-clk (cristal-clk)
    SPI->SPI_MR &= ~SPI_MR_WDRBT;                                      // clear WDRBT at calc-startup
    if((PMC->PMC_MCKR & PMC_MCKR_CSS) == PMC_MCKR_CSS_PLLA_CLK) {      // if PLL-A is enabled ..
        if((PMC->CKGR_PLLAR & CKGR_PLLAR_DIVA) > 0) {                  // .. if PLL-divisor set ..
            s_clksrc /= (PMC->CKGR_PLLAR & CKGR_PLLAR_DIVA);           // div clk with PLL-A div
        }
        s_clksrc *= (((PMC->CKGR_PLLAR & CKGR_PLLAR_MULA) >> 16) + 1); // mul clk with PLL-A multiplier
		if(PMC->PMC_MCKR & PMC_MCKR_PLLADIV2) {
		    s_clksrc /= 2;
		}
    }
    s_clksrc /= (0x0001UL << ((PMC->PMC_MCKR & PMC_MCKR_PRES) >> 4));  // div clk with MCK-div
    i = 1;                                                             // search lowest clk-div for SPI-speed (highest possible SPI-speed)
    while(((s_clksrc / i) > maxclk) && (i != 0)) i++;
    if(i != 0) SPI->SPI_CSR[0] = (SPI->SPI_CSR[0] & ~SPI_CSR_SCBR) | (i << 8);
    return((i)? (s_clksrc / i) : 0);                       // set SPI-div and return the used SPI-speed in Hz
}

#ifdef USE_MMC_DMA
OS_CONST U08 dbFF[512] = {
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

/*
************************************************************
*            transfer a block via DMA to device
************************************************************
*/
U08 FFSPort_MMC_TxBlock(U08 OS_HUGE *block, U32 len)
{
    volatile U32 dummy;

    SPI->SPI_RPR  = 0;                                     // no receive buffer
    SPI->SPI_RCR  = 0;
    SPI->SPI_TPR  = (U32)block;                            // set source ptr ...
    SPI->SPI_TCR  = len;                                   // ... and length
    while(!(SPI->SPI_SR & SPI_SR_TXBUFE));                 // wait for TX-count zero
    while(!(SPI->SPI_SR & SPI_SR_TXEMPTY));                // wait for transmit fully complete
    dummy = SPI->SPI_RDR;                                  // empty receiver-register
    return(0);
}

/*
************************************************************
*            receive a block via DMA from device
************************************************************
*/
U08 FFSPort_MMC_RxBlock(U08 OS_HUGE *block, U32 len)
{
    SPI->SPI_RPR  = (U32)block;                            // set destination ptr ...
    SPI->SPI_RCR  = len;                                   // ... and length
    SPI->SPI_TPR  = (U32)dbFF;                             // set dummy-source ptr ...
    SPI->SPI_TCR  = len;                                   // ... and length
    while(!(SPI->SPI_SR & SPI_SR_RXBUFF));                 // wait for end of receive
    return(0);
}

/*
************************************************************
*            write a char and read one back
************************************************************
*/
U08 FFSPort_MMC_Send(U08 w)
{
    while(!(SPI->SPI_SR & SPI_SR_TDRE));                   // wait up to tx-empty
    SPI->SPI_TDR = w;                                      // write char and send
    while(!(SPI->SPI_SR & SPI_SR_RDRF));                   // wait up to rx-full (char received)
    return((U08)SPI->SPI_RDR);                             // return received char
}

/*
************************************************************
*              reinitialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_ReInit(void)
{
    SPI->SPI_CR      = SPI_CR_SPIDIS;                      // disable SPI
    SPI->SPI_CR      = SPI_CR_SPIEN | SPI_CR_SWRST;        // enable & reset SPI
    SPI->SPI_MR      = SPI_MR_MODFDIS | SPI_MR_MSTR;       // fault-off + (fix) + master
    SPI->SPI_CSR[0]  = SPI_CSR_SCBR | SPI_CSR_BITS_8_BIT | SPI_CSR_CPOL;  // low-speed +  8bit + clk-pol (mode 3)
    SPI->SPI_CR      = SPI_CR_SPIEN;                       // enable SPI
    FFSPort_MMC_SetBR(400000);                             // set SPI-clk to max 400kHz as startup (should never be > 400kHz, says MMC)
    return(0);                                             // return actual alltimes ok.
}

/*
************************************************************
*            card-detect inclusive a INT
************************************************************
*/
U08 FFSPort_MMC_CD(void)
{
    if((PIOA->PIO_PDSR & MMC_SPI_CD) || (FFSPort_MMC_CDi)) { // card-detect
        FFSPort_MMC_CDi = 0;                               // clear INT for "was seen"
        return(1);                                         // card is/was removed
    }
    return(0);                                             // card is still detect
}

/*
************************************************************
*              initialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_Init(void)
{
    FFSPort_MMC_CDi       = 0;                             // no INT was seen
    PMC->PMC_WPMR         = 0x504D4300;                    // disable PMC write protect
    SPI->SPI_WPMR         = 0x53504900;                    // disable SPI write protect
    PIOA->PIO_WPMR        = 0x50494F00;                    // disable PIO write protect
    PIOA->PIO_PDR         = MMC_SPI_MISO | MMC_SPI_MOSI | MMC_SPI_SPCK;     // disable from PIO-mode
    PIOA->PIO_ABCDSR[0]  &= ~(MMC_SPI_MISO | MMC_SPI_MOSI | MMC_SPI_SPCK);  // enable peripheral-functions A
    PIOA->PIO_ABCDSR[1]  &= ~(MMC_SPI_MISO | MMC_SPI_MOSI | MMC_SPI_SPCK);  // enable peripheral-functions A
    PIOA->PIO_PER         = MMC_SPI_CD | MMC_SPI_WP;       // enable GPIO of CD & WP
    PIOA->PIO_ODR         = MMC_SPI_CD | MMC_SPI_WP;       // output disable CD & WP
    PIOA->PIO_OWDR        = MMC_SPI_CD | MMC_SPI_WP;       // write disable  CD & WP
    PIOA->PIO_PUER        = MMC_SPI_CD | MMC_SPI_WP;       // pullup enable  CD & WP
    PMC->PMC_PCER0        = (1 << ID_PIOA);                // enable clock on PIO-interface A for reading
    PIOA->PIO_IFER        = MMC_SPI_CD;                    // enable glitch filter on CD
    PIOA->PIO_IER         = MMC_SPI_CD;                    // enable INT for this PIO-pin
    NVIC_EnableIRQ(PIOA_IRQn);                             // enable PIOA interrupt
    PIOA->PIO_PER         = MMC_SPI_NPCS0;                 // enable GPIO of CS-pin
    PIOA->PIO_OWER        = MMC_SPI_NPCS0;                 // enable write   CS-pin
    PIOA->PIO_SODR        = MMC_SPI_NPCS0;                 // set high       CS-pin
    PIOA->PIO_PUER        = MMC_SPI_NPCS0;                 // pullup enable  CS-pin
    PIOA->PIO_OER         = MMC_SPI_NPCS0;                 // output enable  CS-pin
    PMC->PMC_PCER0        = (1 << ID_SPI);                 // enable clock on SPI-interface
#ifdef USE_MMC_DMA
    SPI->SPI_PTCR         = SPI_PTCR_TXTDIS | SPI_PTCR_RXTDIS; // disable SPI-DMA TX/RX
    SPI->SPI_TPR          = 0;                             // init TX
    SPI->SPI_TCR          = 0;
    SPI->SPI_RPR          = 0;                             // init RX
    SPI->SPI_RCR          = 0;
    SPI->SPI_TNPR         = 0;                             // init "next" TX
    SPI->SPI_TNCR         = 0;
    SPI->SPI_RNPR         = 0;                             // init "next" RX
    SPI->SPI_RNCR         = 0;
    SPI->SPI_PTCR         = SPI_PTCR_TXTEN | SPI_PTCR_RXTEN;   // enable SPI-DMA TX/RX
#endif
    return(FFSPort_MMC_ReInit());
}

/***********************************************************
*       !!!!!! SPI ISR handler (card removed) !!!!!!       *
***********************************************************/
void PIOA_IRQHandler(void)
{
    if(PIOA->PIO_ISR & MMC_SPI_CD) {
        if(PIOA->PIO_PDSR & MMC_SPI_CD)                    // card-lost or card-inserted
            FFSPort_MMC_CDi = 1;                           // remember a lost-card interrupt
    }
}
