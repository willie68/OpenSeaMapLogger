/***********************************************************
*        a FREE MMC/SD-interface to SPI-slot of STM32      *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_MMC.c                       *
*                   MMC/SD TO SPI PORT                     *
************************************************************
*      - code generation            Frank Goetze   01/2008 *
***********************************************************/

#include "../../../inc/MMC/STM32/FFSPort_SPI.h"

/****************** constant variables ********************/
#define CPU_CRISTAL_CLK  8000000UL                         // processor crystal-clock in Hz
OS_CONST U16 OS_ROMDATA SPI_c[] = {
    SPI_BaudRatePrescaler_2,
    SPI_BaudRatePrescaler_4,
    SPI_BaudRatePrescaler_8,
    SPI_BaudRatePrescaler_16,
    SPI_BaudRatePrescaler_32,
    SPI_BaudRatePrescaler_64,
    SPI_BaudRatePrescaler_128,
    SPI_BaudRatePrescaler_256
};

/*
************************************************************
*          set max possible baudrate and return this
************************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk)
{
    RCC_ClocksTypeDef  rcc_clocks;
    U32                s_clksrc;
    U08                i;
    
    i = 0;
    RCC_GetClocksFreq(&rcc_clocks);
#if (!SPI_)
    s_clksrc = (U32)rcc_clocks.PCLK2_Frequency;
#else
    s_clksrc = (U32)rcc_clocks.PCLK1_Frequency;
#endif
    while(((s_clksrc / (2UL << i)) > maxclk) && (i < 7)) i++;
    SPIx->CR1 = (SPIx->CR1 & ~SPI_BaudRatePrescaler_256) | SPI_c[i];
    return(s_clksrc / (2UL << i));
}

#ifdef USE_MMC_DMA
OS_CONST U08 dbFF = 0xFF;
/*
************************************************************
*            transfer a block via DMA to device
************************************************************
*/
U08 FFSPort_MMC_TxBlock(U08 OS_HUGE *block, U32 len)
{
    volatile U32 dummy;

    DMA_tx->CCR  |= DMA_MemoryInc_Enable;                  // inc of memory address
    DMA_tx->CMAR  = (U32)block;                            // set source ...
    DMA_tx->CNDTR = len;                                   // ... and length 
    DMA_tx->CCR  |= 1;                                     // start transmit-DMA
    while(!DMA_GetFlagStatus(DMA_tf));                     // wait for transmit fully complete
    DMA_tx->CCR  &= ~1;                                    // stop transmit-DMA
    DMA_ClearFlag(DMA_tf);                                 // clear flag
    dummy = SPIx->DR;                                      // empty receiver-register
    return(0);
}

/*
************************************************************
*            receive a block via DMA from device
************************************************************
*/
U08 FFSPort_MMC_RxBlock(U08 OS_HUGE *block, U32 len)
{
    DMA_rx->CMAR  = (U32)block;                            // set destination ...
    DMA_rx->CNDTR = len;                                   // ... set length 
    DMA_tx->CCR  &= ~DMA_MemoryInc_Enable;                 // no inc of memory address
    DMA_tx->CMAR  = (U32)&dbFF;                            // set dummy-"FF" as source ...
    DMA_tx->CNDTR = len;                                   // ... set length of dummy-send "FF" 
    DMA_rx->CCR  |= 1;                                     // start receive-DMA
    DMA_tx->CCR  |= 1;                                     // start dummy transmit-DMA
    while(!DMA_GetFlagStatus(DMA_tf));                     // wait for dummy-transmit fully complete
    while(!DMA_GetFlagStatus(DMA_rf));                     // wait for receive fully complete
    DMA_tx->CCR  &= ~1;                                    // stop transmit-DMA
    DMA_rx->CCR  &= ~1;                                    // stop receive-DMA
    DMA_ClearFlag(DMA_tf);                                 // clear flag
    DMA_ClearFlag(DMA_rf);                                 // clear flag
    return(0);
}
#endif
  
/*
************************************************************
*            write a char and read one back
************************************************************
*/
U08 FFSPort_MMC_Send(U08 w)
{
    while(!(SPI_GetFlagStatus(SPIx, SPI_FLAG_TXE)));       // wait up to tx-empty
    SPI_SendData(SPIx, (U16)w);                            // write char and send
    while(!(SPI_GetFlagStatus(SPIx, SPI_FLAG_RXNE)));      // wait up to rx-not_empty (char received)
    return((U08)SPI_ReceiveData(SPIx));                    // return received char
}

/*
************************************************************
*              reinitialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_ReInit(void)
{
    FFSPort_MMC_SetBR(400000);                             // set SPI-clk to max 400kHz as startup (should never be > 400kHz, says MMC)
    return(0);                                             // return actual alltimes ok.
}

/*
************************************************************
*              initialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_Init(void)
{
    SPI_InitTypeDef   SPI_is;
    GPIO_InitTypeDef  GPIO_is; 
#ifdef USE_MMC_DMA
    DMA_InitTypeDef   DMA_is;
#endif

#if (!SPI_)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);   // enable CLK for SPI1
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  // enable CLK for GPIOA (CS)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // enable CLK for GPIOC (WP & CD)
#else
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);   // enable CLK for SPI2
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  // enable CLK for GPIOB (CS)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  // enable CLK for GPIOC (WP & CD)
#endif
    SPI_is.SPI_Direction         = SPI_Direction_2Lines_FullDuplex;
    SPI_is.SPI_Mode              = SPI_Mode_Master;        // init SPIx
    SPI_is.SPI_DataSize          = SPI_DataSize_8b;
    SPI_is.SPI_CPOL              = SPI_CPOL_High;
    SPI_is.SPI_CPHA              = SPI_CPHA_2Edge;
    SPI_is.SPI_NSS               = SPI_NSS_Soft;
    SPI_is.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_256;
    SPI_is.SPI_FirstBit          = SPI_FirstBit_MSB;
    SPI_is.SPI_CRCPolynomial     = 7;
    SPI_Init(SPIx, &SPI_is);

    GPIO_is.GPIO_Speed = GPIO_Speed_50MHz;                 // config SCK, MOSI, MISO 
    GPIO_is.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_is.GPIO_Pin   = SPIx_bit;
    GPIO_Init(SPIx_Gx, &GPIO_is);
    GPIO_is.GPIO_Mode  = GPIO_Mode_IN_FLOATING;            // config WP, CD as PIO in
    GPIO_is.GPIO_Pin   = WP_bit | CD_bit;
    GPIO_Init(WPCD_Gx, &GPIO_is);
    GPIO_is.GPIO_Mode  = GPIO_Mode_Out_PP;                 // config NSS as PIO out
    GPIO_is.GPIO_Pin   = CS_bit;
    GPIO_Init(CS_Gx, &GPIO_is);
    
#ifdef USE_MMC_DMA
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    SPI_DMACmd(SPIx, SPI_DMAReq_Tx | SPI_DMAReq_Rx, ENABLE);
    DMA_DeInit(DMA_rx);                                    // RX DMA-channel
    DMA_is.DMA_PeripheralBaseAddr = (U32)&SPIx->DR;
    DMA_is.DMA_MemoryBaseAddr     = 0;
    DMA_is.DMA_DIR                = DMA_DIR_PeripheralSRC;
    DMA_is.DMA_BufferSize         = 1;
    DMA_is.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
    DMA_is.DMA_MemoryInc          = DMA_MemoryInc_Enable;
    DMA_is.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
    DMA_is.DMA_MemoryDataSize     = DMA_MemoryDataSize_Byte;
    DMA_is.DMA_Mode               = DMA_Mode_Normal;
    DMA_is.DMA_Priority           = DMA_Priority_Medium;
    DMA_is.DMA_M2M                = DMA_M2M_Disable;
    DMA_Init(DMA_rx, &DMA_is);
    DMA_DeInit(DMA_tx);                                    // TX DMA-channel
    DMA_is.DMA_DIR                = DMA_DIR_PeripheralDST;
    DMA_is.DMA_MemoryBaseAddr     = (U32)&dbFF;
    DMA_is.DMA_MemoryInc          = DMA_MemoryInc_Disable;
    DMA_is.DMA_Priority           = DMA_Priority_Low;
    DMA_Init(DMA_tx, &DMA_is);
#endif
    
    SPI_Cmd(SPIx, ENABLE);
    return(FFSPort_MMC_ReInit());                          // (re)init SPI-clock
}

/************************** END ***************************/
