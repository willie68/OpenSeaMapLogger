/***********************************************************
*      a FREE MMC/SD-interface to SPI-slot of ATMega128    *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_MMC.c                       *
*                   MMC/SD TO SPI PORT                     *
************************************************************
*      - code generation            Frank Goetze   09/2007 *
***********************************************************/

#include "../../../inc/MMC/ATMega128/FFSPort_SPI.h"

/****************** constant variables ********************/
#define  CPU_CRISTAL_CLK  14745600UL                       // processor cristal-clock in Hz
OS_CONST U08 OS_ROMDATA SPI_c[] = {0x80,0x00,0x81,0x01,0x82,0x02,0x03};

/*
************************************************************
*          set max possible baudrate and return this
************************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk)
{
    U08 i;
	
    i = 0;
    while(((CPU_CRISTAL_CLK / (2 << i)) > maxclk) && (i < 6)) i++;
    SPCR = (SPCR & 0xFC) | (SPI_c[i] & 0x03);
    SPSR = SPI_c[i] >> 7;
    return(CPU_CRISTAL_CLK / (2 << i));
}

/*
************************************************************
*            write a char and read one back
************************************************************
*/
U08 FFSPort_MMC_Send(U08 w)
{
    SPDR = w;
    while(!(SPSR & (1 << SPIF)));
    return(SPDR);
}

/*
************************************************************
*              reinitialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_ReInit(void)
{
    U08 i;
    
    SPCR   = 0x5F;                                         // 0101 1111: set enable,MSB,master,lowest-speed
    i      = SPSR;                                         // clear flags
    SPSR   = 0x00;                                         // normal-clk
    FFSPort_MMC_SetBR(400000);                             // set SPI-clk to max 400kHz as startup (should never be > 400kHz, says MMC)
    return(0);                                             // return actual alltimes ok.
}
/*
************************************************************
*               initialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_Init(void)
{
    PORTB |= 0x3F;                                         // 0011 1111: set WE,CD,MISO,MOSI,SCK,SS high (MISO with pull-up)
    DDRB  |= 0x07;                                         // 0000 0111: set MOSI,SCK,SS as output
    DDRB  &= 0xC7;                                         // 1100 0111: set WE,CD,MISO as input
    return(FFSPort_MMC_ReInit());
}

