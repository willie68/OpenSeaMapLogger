/***********************************************************
*     a FREE FFS/FAT Port to MMC/SD-slot using SPI-mode    *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                     FFS_Port_MMC.c                       *
*                 FFS/FAT to MMC(SPI) PORT                 *
************************************************************
*      - code generation            Frank Goetze   06/2007 *
*      - redesign & SDHC-support    Frank Goetze   09/2007 *
*      - split SD1.xx and (HD-)MMC  Frank Goetze   01/2008 *
*        detection                                         *
*      - add support for older      Frank Goetze   01/2008 *
*        MMCs and none-standard SDs                        *
*      - add support for MMCplus    Frank Goetze   02/2008 *
*        (HS-MMC) and HD-MMC cards                         *
*        -> HD-MMC not tested !!!                          *
*      - add lost lines for HD-MMC  Frank Goetze   03/2008 *
*      - add support for SAM7SExx   Frank Goetze   04/2008 *
*        and DMA mode for sectors                          *
*      - small bugfix for HD-MMC    Frank Goetze   01/2009 *
*      - support for SDXC cards     Frank Goetze   05/2009 *
*        added (SD 3.00)                                   *
*      - correction in Nac and Nbs  Frank Goetze   07/2009 *
*        calculation, SDHC fix                             *
*        to 100ms and 250ms                                *
*        SDXC 100ms and 500ms                              *
*      - new timeout handing for    Frank Goetze   09/2010 *
*        card registers, optional                          *
*        additional info from card                         *
*      - add detection of SD 4.00   Frank Goetze   01/2012 *
*      - add optional McEx/ASSD     Frank Goetze   08/2012 *
*        support                                           *
*      - correct CRC7 plus end-bit  Frank Goetze   10/2013 *
*        for CMD8                                          *
*                                                          *
************************************************************
*  supported cards:                                        *
*   * MMC, RS-MMC, MMCplus(HS-MMC), MMCmobile, MMCmicro,   *
*     HD-MMC                                               *
*   * M-Bridge                                             *
*   * SD(SDSC), SDHC, SDXC in all form factors             *
*   * secure micro SD (optional, using add-on)             *
***********************************************************/

#include "../../inc/MMC/FFS_Port_MMC.h"

/****************** constant variables ********************/
OS_CONST U08 OS_ROMDATA MMC_m[] = {10,12,13,15,20,25,30,35,40,45,50,55,60,70,80};

/******************* global variables *********************/
FFS_SIZE  FFS_values;                                      // device-informations
       U08  FFSp_data[64];                                 // array for reading Rx, CID, CSD
       U08  FFSp_ver;                                      // holder for version (to support SDHC/SDXC and HD-MMC)
static U08  FFSp_sshift;                                   // holder for sec-to-addr shifter (on SDHC/SDXC and HD-MMC its 0 since we use sector-numbers)
       U32  MMC_Nac;                                       // time between CMD-R1 & data on reading (also Ncx)
       U32  MMC_Nbs;                                       // time between data-responce & finish on writing (max busy-time)
       U32  MMC_uSpeed;                                    // used speed in Hz (used by optional modules too)

#ifdef MMC_EXT_CSD_CHECK
 U08      FFSp_exCSD[512];
#endif

/*
************************************************************
*            write a command to the MMC/SD
************************************************************
*/
U08 MMCWriteCMD(U08 cmd, U32 arg, U08 end)
{
    U08 cnt, res;

    cnt = 0;
    switch(cmd) {                                          // get CRC7s for cmds in front of CRC-OFF
        case MMC_GO_IDLE_STATE: res = 0x95; break;         // valid CRC7 plus end-bit for RESET
        case SD_SEND_IF_COND: res = 0x87; break;           // valid CRC7 plus end-bit for IF_COND(0x1AA) on SD/SDHC/SDXC-cards
        default: res = 0xFF; break;
    }
    FFSPort_MMC_Send(0xFF);                                // wait "Nrc" in front of CMD
    FFSPort_MMC_CS_ON;                                     // enable MMC-interface
    FFSPort_MMC_Send(cmd | 0x40);                          // write CMD plus start-flag
    FFSPort_MMC_Send((U08)(arg >> 24));                    // write parameter (automatic endian corrected)
    FFSPort_MMC_Send((U08)(arg >> 16));
    FFSPort_MMC_Send((U08)(arg >>  8));
    FFSPort_MMC_Send((U08)(arg));
    FFSPort_MMC_Send(res);                                 // write (dummy)-CRC7
    if(cmd == MMC_STOP_TRANSMISSION)
        FFSPort_MMC_Send(0xFF);                            // skip stuff-byte after STOP_TRANSMISSION cmd
    do {
        res = FFSPort_MMC_Send(0xFF); cnt++;               // wait "Ncr" for R1 or R1b (normally 1..8 pings)
    } while((res == 0xFF) && (cnt < 8));
    if(res == 0xFE) res = FFSPort_MMC_Send(0xFF) >> 1;     // older MMC-cards comes 1-bit to early on R1
    if(end) FFSPort_MMC_CS_OFF;                            // disable MMC-interface
    return(res);                                           // last value
}

/*
************************************************************
*          write a R2..R7-command to the MMC/SD
************************************************************
*/
U08 MMCWriteCMD_Rx(U08 cmd, U32 arg, U08 OS_HUGE *buff, U32 count)
{
    U32 i;
    U08 r1;

    r1 = MMCWriteCMD(cmd, arg, 0);                         // send CMD(arg) and collect first 8bits of Rx (as R1)
    for(i = 0; i < count; i++) {                           // (older MMCs do not support the used cmds - so need here no correction)
        buff[i] = FFSPort_MMC_Send(0xFF);                  // read additional Rx bytes
    }
    FFSPort_MMC_CS_OFF;                                    // disable MMC-interface
    return(r1);                                            // return r1 for caller
}

/*
************************************************************
*              read status from the MMC/SD
************************************************************
*/
U08 MMCReadStatus(U08 r1)
{
    U08 r[3] = {0,0,0};

    r[0] = r1;                                             // notice R1
    r[1] = MMCWriteCMD(MMC_SEND_STATUS, 0, 0);             // read   R2
    r[2] = FFSPort_MMC_Send(0xFF);                         // control-read (should be 0xFF as readed data)
    FFSPort_MMC_CS_OFF;                                    // disable MMC-interface
    if(r[0] == 0xFF) return(FFS_PORT_ERR);                 // if no direct error-code given from caller, return

    // you can decode R1 & R2 here

    return(r1);                                            // return r1 for caller
}

/*
************************************************************
*         read a R1-command block from the MMC/SD
************************************************************
*/
U08 MMCReadBlock(U08 cmd, U32 arg, U08 OS_HUGE *buff, U32 count, U08 creg)
{
    U32 i;
    U08 res;
                                                           // "creg" triggers longer time to wait for response (we use Nbs)
    i = 0;
    res = MMCWriteCMD(cmd, arg, 0);
    if(res != FFS_NO_ERR) {                                // wrong response! ..
        FFSPort_MMC_CS_OFF;                                // .. disable MMC-interface ...
        return(MMCReadStatus(res));                        // ... read status & return the error
    }
    do {
        res = FFSPort_MMC_Send(0xFF); i++;                 // wait "Nac"/"Ncx" for startbyte (0xFE)
    } while((res == 0xFF) && (i < ((creg)? MMC_Nbs : MMC_Nac)));
    if(i >= ((creg)? MMC_Nbs : MMC_Nac)) {                 // startbyte received ? ..
        FFSPort_MMC_CS_OFF;                                // .. disable MMC-interface ...
        return(MMCReadStatus(res));                        // ... read status & return the error
    }
    if(!(res & 0x02)) {                                    // older MMC-cards comes 1-bit to early
        U08 s;

        for(i = 0; i < count; i++) {
            s = (U08)(res << 7);                           // save old bits of new byte
            res = FFSPort_MMC_Send(0xFF);                  // get new byte
            buff[i] = (res >> 1) | s;                      // store valid bits of new and saved bits
        }
    } else {                                               // --> actual cards
#ifdef USE_MMC_DMA
        FFSPort_MMC_RxBlock(buff, count);                  //   - read data via DMA
#else
        for(i = 0; i < count; i++) {
            buff[i] = FFSPort_MMC_Send(0xFF);              //   - read data
        }
#endif
    }
    FFSPort_MMC_Send(0xFF); FFSPort_MMC_Send(0xFF);        // read 2 bytes CRC16 (not used)
    FFSPort_MMC_CS_OFF;                                    // disable MMC-interface
    return(FFS_NO_ERR);
}

/*
************************************************************
*            initialise the FFS-Port (no media-init)
************************************************************
*/
U08 FFSPort_Init(void)
{
    MMC_Nac = 8;                                           // Ncx as first "wait for data on read" value - up to CSD was read
    MMC_Nbs = 1024;                                        // Nbusy set, to be shure its not zero        - up to CSD was read
    if(FFSPort_MMC_Init()) return(FFS_PORT_ERR);           // init low-level (hardware specific)
    return(FFS_NO_ERR);
}

/*
************************************************************
*                check media presence
************************************************************
*/
U08 FFSPort_MediaDetect(void)
{
    if(FFSPort_MMC_CD()) {                                 // check if a card present
        MMC_Nac = 8;                                       // Ncx as first "wait for data on read" value - up to CSD was read
        MMC_Nbs = 1024;                                    // Nbusy set, to be shure its not zero        - up to CSD was read
        return(FFS_NO_MEDIA);
    }
    return(FFS_NO_ERR);
}

#ifdef MMC_EXT_CSD_CHECK
/*
************************************************************
*  check and handle EXT-CSD from MMCplus- & HD-MMC- cards
************************************************************
*/
U32 MMCHandle_ExtCsd(U08 card_type, U32 s_speed, U32 c_size, U16 c_size_mult)
{
    U32 h_speed, tmp;
    
    h_speed = 0;                                           // default no higher-speed is set
    if((((FFSp_data[0] & 0xC0) >> 6) >= 2) && (((FFSp_data[0] & 0x3C) >> 2) >= 4)) {         // be shure it's a MMC4.x card
        // why some cards are MMC4.x cards but do not support EXT_CSD ???
        // ... and why some cards are not MMC4.x but supports EXT_CSD ???
        if(MMCReadBlock(MMC_SEND_EXTCSD, 0, (U08 OS_HUGE *)FFSp_exCSD, 512, 1) == FFS_NO_ERR) { // read EXT_CSD
            tmp = ((U32)(FFSp_exCSD[215]) << 24) | ((U32)(FFSp_exCSD[214]) << 16) | ((U32)(FFSp_exCSD[213]) << 8) | FFSp_exCSD[212];
            if((FFSp_exCSD[192] >= 2)) {                   // EXT_CSD.sec_count can only be valid for HD-MMC if EXT_CSD Rev. 1.2 and higher
                if((c_size == 0x0FFF) && (c_size_mult == (0x0001 << 9)) && (tmp != 0)) {
                    FFS_values.maxsectors = tmp;           // MMC4.2 says, "c_size" & "c_size_mult" should be set to "max" and a valid sec_count in EXT_CSD
                    FFS_values.sectorsize = 512;           // this sec_count is based on fix 512bytes/sector (also as default blocklength)
                    if(card_type == FFSp_MARK_HDMMC) {     // if HD-MMC -> we work block-based
                        FFSp_sshift = 0;                   // code-compatibility -> no shift needed 
                    }
                }
            }
            if(FFSp_exCSD[196] == 0x03) {                  // if hs-timing possible
                if(MMCWriteCMD(MMC_SWITCH, 0x03B90100, 1) == FFS_NO_ERR) { // 03-switch mode(write-byte) , B9-185(hs_timing) , 01-value , 00-set
#ifdef FFS_MMC_ADD_INFO
                    FFS_values.mSpeed = 52000000;
#endif
                    h_speed = FFSPort_MMC_SetBR(52000000); // was switched -> set "EXT_CSD - high-speed" and return used-speed
                }
            } else {
#ifdef FFS_MMC_ADD_INFO
                FFS_values.mSpeed = 26000000;
#endif
                h_speed = FFSPort_MMC_SetBR(26000000);     // set "EXT_CSD - normal-speed" and return used-speed
            }
            for(tmp = 0; tmp < 0xFFFF; tmp++) { _NOP(); _NOP(); _NOP(); }   // wait for resync card-internally (processor-speed depending)
            if(h_speed <= s_speed) h_speed = 0;            // nothing changed (no timing recalculation needed)
        }
    }
    return(h_speed);                                       // if not zero -> timing recalculation is needed
}

/*
************************************************************
*  check and handle possible HS-mode from SD- cards
************************************************************
*/
U08 MMCHandle_HsSD(void)
{
    U08 i;
    
    i = 0;
    do {
        if(MMCReadBlock(MMC_SWITCH, 0x00FFFFFF, (U08 *)FFSp_exCSD, 64, 1) != FFS_NO_ERR) return(FFS_PORT_ERR);
        if(!(FFSp_exCSD[13] & 0x02)) return(FFS_PORT_ERR);     // HS mode not supported (supported-bits group no 1)
        if(MMCReadBlock(MMC_SWITCH, 0x80FFFFF1, (U08 *)FFSp_exCSD, 64, 1) != FFS_NO_ERR) return(FFS_PORT_ERR);
    } while(((FFSp_exCSD[16] & 0x0F) == 0x0F) && ((i++) < 0xFF));  // switch to mode and check result-status
    if((FFSp_exCSD[16] & 0x0F) != 0x01) return(FFS_PORT_ERR);  // HS mode not supported
    return(FFS_NO_ERR);                                        // no error
}
#endif

/*
************************************************************
*    initialise the MMC/SD-card and get some card-data
************************************************************
*/
FFS_SIZE *FFSPort_MediaInit(void)
{
    U32 c_size, s_div, hs_speed;
    U16 c_size_mult;
    U08 i;

    FFSp_ver = FFSp_MARK_MMC;                              // mark as normal MMC-card at start-up
    for(i = 0; i < 0xFF; i++) { _NOP(); _NOP(); _NOP(); }  // wait for a stable card, 1ms (says MMC)
    if(FFSPort_MediaDetect()) return(NULL);                // media present ?
    FFSPort_MMC_ReInit();                                  // reinit interface (clock)
    for(i = 0; i < 10; i++) FFSPort_MMC_Send(0xFF);        // start MMC/SD in SPI-Mode, card-reset (74+ ckl)
    i = 0;                                                 // set IDLE_MODE (repeat)
    while((MMCWriteCMD(MMC_GO_IDLE_STATE, 0, 1) != MMC_R1_IDLE_STATE) && (i < 0xFF)) i++;
    if(i == 0xFF) return(NULL);                            // TimeOut error
    // After CMD0 the SPI interface is initialized in the CRC OFF mode in default.
    // But the CMD8 CRC verification is always enabled. (send VHS 01h plus Check-pattern AAh) 
    i = MMCWriteCMD_Rx(SD_SEND_IF_COND, 0x1AA, (U08 OS_HUGE *)FFSp_data, 4); // send CMD8 to see it is SD & extended card and expand ACMD41 (R1-part of R7)
    // for not-MMC4.x and not-SD2.x cards CMD8 is unknown -- for MMC4.x cards CMD8 is not allowed here (in front of CMD1 / CMD58)    
    if(i <= MMC_R1_IDLE_STATE) {                           // ======== SD 2.00 / SD 3.00 / SD 4.00 ========
        FFSp_ver = FFSp_MARK_SD;                           // mark as SD-card
        // why some SD 2.xx cards response with "bullshit-data" on CMD8 (like 0xFF pattern) but the rest is functional ???
//        if(!(FFSp_data[2] & 0x01) || (FFSp_data[3] != 0xAA)) return(NULL);  // check CMD8 R7-response -> unsupported card
        c_size = 0;                                        // repeat ACMD41 - HCS (High Capacity Support) bit is in the argument of ACMD41 (SD 2.00++)
        while(((MMCWriteCMD(MMC_APP_CMD, 0, 1) > MMC_R1_IDLE_STATE ) ||             
               (MMCWriteCMD(SD_SEND_OP_COND_ACMD41, 1UL << 30, 1) !=  FFS_NO_ERR)) && (c_size < 0xFFFF)) c_size++;
        if(c_size == 0xFFFF) return(NULL);                 // TimeOut error
        i = MMCWriteCMD_Rx(MMC_READ_OCR, 0, (U08 OS_HUGE *)FFSp_data, 4);
        if(i != FFS_NO_ERR) return(NULL);                  // send CMD58 (check R1-part of R3) ..
        FFSp_ver |= (FFSp_data[0] & 0x40) >> 6;            // and copy CCS-bit from R3 (SDHC/SDXC-card)
    } else {                                               // ============= SD 1.xx / (HD-)MMC ============
        // why some SD 1.xx cards response with "bullshit" on CMD8 (like 0x82) but the rest is functional ???
//        if(i & ~(MMC_R1_ILLEGAL_COM | MMC_R1_IDLE_STATE)) return(NULL); // more R1-flags than IDLE & ILLEGAL_CMD -> unsupported card
        c_size = 0; i = MMC_R1_ILLEGAL_COM;                // repeat ACMD41 - HCS (High Capacity Support) bit is NOT in the argument of ACMD41 (SD 1.xx)
        while((((s_div = MMCWriteCMD(MMC_APP_CMD, 0, 1)) > MMC_R1_IDLE_STATE ) ||             
               ((i = MMCWriteCMD(SD_SEND_OP_COND_ACMD41, 0, 1)) != FFS_NO_ERR)) && (c_size < 0xFFFF)) {
            if((s_div != 0xFF) && (i & MMC_R1_ILLEGAL_COM)) break;
            c_size++;
        }
        if(c_size == 0xFFFF) return(NULL);                 // TimeOut error
        if(i & MMC_R1_ILLEGAL_COM) {                       // ================== (HD-)MMC =================
            FFSp_ver = FFSp_MARK_MMC;                      // be shure is marked as MMC-card
            c_size = 0; s_div = 1UL << 30;                 // send MMC_OP_MODE w/wo HD-support (repeat)
            while(((i = MMCWriteCMD(MMC_SEND_OP_COND, s_div, 1)) != FFS_NO_ERR) && (c_size < 0xFFFF)) {
                c_size++;
                if(i & (MMC_R1_PARAMETER | MMC_R1_ADDRESS)) s_div = 0;  // switch back to normal MMC
            }
            if(c_size == 0xFFFF) return(NULL);             // TimeOut error
            if(s_div) {                                    // if possible HD-MMC ..
                i = MMCWriteCMD_Rx(MMC_READ_OCR, 0, (U08 OS_HUGE *)FFSp_data, 4);
                if(i != FFS_NO_ERR) return(NULL);          // .. send CMD58 (check R1-part of R3) ..
                FFSp_ver |= ((FFSp_data[0] & 0x60) == 0x40)? FFSp_MARK_HDMMC : FFSp_MARK_MMC;
            }                                              // .. and test bit30/29 from R3 (HD-MMC card)
        } else {                                           // ================== SD 1.xx ==================
            FFSp_ver = FFSp_MARK_SD;                       // mark as SD-card
        }
    }
    /***********   get needed card information  ***********/
    i = MMCReadBlock(MMC_SEND_CID, 0, (U08 OS_HUGE *)FFSp_data, 16, 1);           // read CID for vendor- & product- ID
    if(i != FFS_NO_ERR) return(NULL);
    FFS_values.vp_id = ((U32)FFSp_data[0] << 16) | (((U16)FFSp_data[2] << 8) | FFSp_data[1]);
    FFS_values.flags = (FFSPort_MMC_WP())? 0x80 : 0;                              // copy vendor- & product-ID plus WP-bit
#ifdef FFS_MMC_ADD_INFO
    for(i = 0; i < (5 + ((FFSp_ver == FFSp_MARK_MMC)? 1 : 0)); i++)               // copy product name as ASCII sting
        FFS_values.PName[i] = FFSp_data[3 + i];
    FFS_values.PName[i] = 0;
    FFS_values.PRev[0]  = (FFSp_data[3 + i] >> 4)  | 0x30;                        // copy product revision as ASCII string
    FFS_values.PRev[1]  = '.';
    FFS_values.PRev[2]  = (FFSp_data[3 + i] & 0xF) | 0x30;
    FFS_values.PRev[3]  = 0;
    FFS_values.PSerial  = ((U32)FFSp_data[3 + i + 1] << 24) |                     // copy product serial as big-endian U32
                          ((U32)FFSp_data[3 + i + 2] << 16) |
                          ((U32)FFSp_data[3 + i + 3] <<  8) | 
                           (U32)FFSp_data[3 + i + 4];
    if(FFSp_ver & (FFSp_MARK_SD | FFSp_MARK_SDHC | FFSp_MARK_SDXC)) {             // for all SD cards ...
        MMC_uSpeed = (((FFSp_data[3 + i + 5] & 0x0F) << 4) | ((FFSp_data[3 + i + 6] & 0xF0) >> 4)) + 2000;  // get year (from 2000)
        FFSp_data[0] = FFSp_data[3 + i + 6] & 0x0F;                               // get mounth
    } else {                                                                      // ... and for MMC cards ...
        FFSp_data[0] = (FFSp_data[3 + i + 5] & 0xF0) >> 4;                        // get mounth
        MMC_uSpeed = (FFSp_data[3 + i + 5] & 0x0F) + 1997;                        // get year (from 1997)
    }
    FFS_values.PMdate[0] = (FFSp_data[0] / 10) | 0x30;
    FFS_values.PMdate[1] = (FFSp_data[0] % 10) | 0x30;
    FFS_values.PMdate[2] = '/';
    FFS_values.PMdate[3] = (MMC_uSpeed / 1000) + 0x30;
    FFS_values.PMdate[4] = ((MMC_uSpeed / 100) % 10) | 0x30;
    FFS_values.PMdate[5] = ((MMC_uSpeed / 10) % 10) | 0x30;
    FFS_values.PMdate[6] = (MMC_uSpeed % 10) | 0x30;
    FFS_values.PMdate[7] = 0;
#endif
    i = MMCReadBlock(MMC_SEND_CSD, 0, (U08 OS_HUGE *)FFSp_data, 16, 1);           // read CSD for card-speed & card-size
    if(i != FFS_NO_ERR) return(NULL);
    if((FFSp_ver == FFSp_MARK_SDHC) && (!(FFSp_data[0] & 0x3C))) {                // doublecheck if SDHC-/SDXC-card with new CSD response ..
        FFSp_ver = (FFSp_data[0] & 0xC0)? FFSp_MARK_SDHC : FFSp_MARK_SD;          // SD-card plus .. scan of CSD-version (for SDHC-/SDXC-cards)
    }
    for(hs_speed = 1, i = FFSp_data[3] & 0x07; i > 0; hs_speed *= 10, i--);       // (TRAN_SPEED_tu*10)
    hs_speed  *= (U32)(MMC_m[((FFSp_data[3] >> 3) & 0x0F) -1]) * 10000;           // (TRAN_SPEED_tu*10) * (TRAN_SPEED_tv*10) * 10000 = x (in Hz)
    MMC_uSpeed = FFSPort_MMC_SetBR(hs_speed);                                     // set max-speed in Hz and return used-speed
#ifdef FFS_MMC_ADD_INFO
    FFS_values.mSpeed = hs_speed;
    FFS_values.Speed  = MMC_uSpeed;
    FFS_values.SpecVer[1] = '.';                                                  // get Spec version from CSD (for MMC, SD overwrites later)
    FFS_values.SpecVer[2] = 'x';
    FFS_values.SpecVer[3] = 0;
    FFS_values.SpecVer[4] = 0;
    switch((FFSp_data[0] & 0x3C) >> 2) {
        case 0: FFS_values.SpecVer[0] = '1'; break;                               // (for all SD versions too)
        case 1: FFS_values.SpecVer[0] = '1'; FFS_values.SpecVer[2] = '4'; break;
        case 2: FFS_values.SpecVer[0] = '2'; break;
        case 3: FFS_values.SpecVer[0] = '3'; break;
        case 4: FFS_values.SpecVer[0] = '4'; break;
        default: FFS_values.SpecVer[0] = '?'; break;
    }
    FFS_values.SecVer[0] = 'n'; FFS_values.SecVer[1] = 's';
	FFS_values.SecVer[2] = 0; FFS_values.SecVer[3] = 0; FFS_values.SecVer[4] = 0;
    if(FFSp_ver & (FFSp_MARK_SD | FFSp_MARK_SDHC | FFSp_MARK_SDXC)) {             // for all SD cards ...
        c_size = 0;
        while(((MMCWriteCMD(MMC_APP_CMD, 0, 1) > MMC_R1_IDLE_STATE ) ||           // ... read SCR to get SD Spec version
               (MMCReadBlock(SD_SEND_CONFIG_REG_ACMD51, 0, &FFSp_data[16], 8, 1) !=  FFS_NO_ERR)) && (c_size < 0xFFFF)) c_size++;
        if(c_size == 0xFFFF) return(NULL);                                        // TimeOut error
        FFS_values.SpecVer[2] = '0'; FFS_values.SpecVer[3] = '0';
        switch((FFSp_data[16 + 2] & 0x80 >> 3) | FFSp_data[16] & 0x0F) {          // detect SD version based on SD_SPEC3 & SD_SPEC
            case 0x00: FFS_values.SpecVer[0] = '1'; FFS_values.SpecVer[3] = 'x'; break;
            case 0x01: FFS_values.SpecVer[0] = '1'; FFS_values.SpecVer[2] = '1'; break;
            case 0x02: FFS_values.SpecVer[0] = '2'; break;
            case 0x12: FFS_values.SpecVer[0] = '3'; FFS_values.SpecVer[3] = 'x'; break;
            case 0x13: FFS_values.SpecVer[0] = '4'; break;
            default:   FFS_values.SpecVer[0] = '?'; break;
        }
        switch((FFSp_data[16 + 1] & 0x70) >> 4) {
            case 0:  FFS_values.SecVer[0] = 'n'; FFS_values.SecVer[1] = 's'; break;
            case 1:  FFS_values.SecVer[0] = 'n'; FFS_values.SecVer[1] = 'u'; break;
            case 2:  FFS_values.SecVer[0] = '1'; FFS_values.SecVer[1] = '.'; FFS_values.SecVer[2] = '0'; FFS_values.SecVer[3] = '1'; break;
            case 3:  FFS_values.SecVer[0] = '2'; FFS_values.SecVer[1] = '.'; FFS_values.SecVer[2] = '0'; FFS_values.SecVer[3] = '0'; break;
            case 4:  FFS_values.SecVer[0] = '3'; FFS_values.SecVer[1] = '.'; FFS_values.SecVer[2] = 'x'; FFS_values.SecVer[3] = 'x'; break;
            default: FFS_values.SecVer[0] = '?'; FFS_values.SecVer[1] = 0; break;
        }
    }
#endif
    for(s_div = 1000, i = 7 - (FFSp_data[1] & 0x07); i > 0; s_div *= 10, i--);    // for: 1 / (TAAC_tu*10)
    c_size   = MMC_uSpeed * (U32)(MMC_m[((FFSp_data[1] >> 3) & 0x0F) - 1]);       // as:  (TAAC_tv*10) * Fop
    MMC_Nac  = (10UL * (c_size / s_div) + 100UL * (U32)(FFSp_data[2])) / 8;       // 10 * ( ((TAAC_tv*10) * Fop) / (TAAC_tu*10) + 100 * NSAC) / 8
    MMC_Nbs  = MMC_Nac * (1UL << ((FFSp_data[12] >> 2) & 0x07));                  // Nac * R2W_factor
    switch(FFSp_ver) {
        case FFSp_MARK_MMC:                                // ******************** normal MMC-cards *********************
        case FFSp_MARK_SD:                                 // ********************* normal SD-cards *********************
            // the maximum capacity can be 4GB, defined by CSD structure and 32bit byte-addressing
            // this is possible on: C_SIZE_MULT   C_SIZE   READ_BL_LEN
            //                        2^(7+2)   *  2^12  *    2^11
            //                         512      *  4096  *    2048      = 4GB
            c_size      = ((U16)(FFSp_data[6] & 0x03) << 10) | ((U16)FFSp_data[7] << 2) | (FFSp_data[8] >> 6);
            c_size_mult = 0x0001 << (2 + (((FFSp_data[9] & 0x03) << 1) | (FFSp_data[10] >> 7)));
            FFSp_sshift = FFSp_data[5] & 0x0F;                         // get READ_BL_LEN as shift-value
            FFS_values.sectorsize = 0x0001UL << FFSp_sshift;           // copy BytsPerSec from READ_BL_LEN
            FFS_values.maxsectors = ((U32)c_size + 1) * c_size_mult;   // get calculated MaxSectors
#ifdef MMC_EXT_CSD_CHECK
            if(FFSp_ver == FFSp_MARK_MMC) {                            // only for MMC-cards ...
                hs_speed = MMCHandle_ExtCsd(FFSp_ver, MMC_uSpeed, c_size, c_size_mult); 
                if(hs_speed != 0) {                                    // if EXT_CSD supported and a new speed set -> we have to recalculate the timings
                    MMC_uSpeed = hs_speed;
 #ifdef FFS_MMC_ADD_INFO
                    FFS_values.Speed = MMC_uSpeed;
 #endif
                    for(s_div = 1000, i = 7 - (FFSp_data[1] & 0x07); i > 0; s_div *= 10, i--);    // for: 1 / (TAAC_tu*10)
                    hs_speed *= (U32)(MMC_m[((FFSp_data[1] >> 3) & 0x0F) - 1]);                   // as:  (TAAC_tv*10) * Fop
                    MMC_Nac   = (10UL * (hs_speed / s_div) + 100UL * (U32)(FFSp_data[2])) / 8;    // 10 * ( ((TAAC_tv*10) * Fop) / (TAAC_tu*10) + 100 * NSAC) / 8
                    MMC_Nbs   = MMC_Nac * (1UL << ((FFSp_data[12] >> 2) & 0x07));                 // Nac * R2W_factor
                    i = MMCReadBlock(MMC_SEND_EXTCSD, 0, (U08 OS_HUGE *)FFSp_exCSD, 512, 1);      // read EXT_CSD again for resync card-internally
                }
            }
#endif
            break;
        case FFSp_MARK_SDHC:                               // ************** highcapacity SDHC-/SDXC-cards **************
            // the maximum capacity can be 2TB (22bit for C_SIZE), defined by CSD 2.0 structure and 32bit block-addressing 
            // for SDHC-cards as maximum defined are 32GB (upper 6bit of C_SIZE should be zero says SD 2.00)
            // for SDXC-cards as maximum defined are 2TB (using the hole 22bit of C_SIZE, see SD 3.00)
            if((FFSp_data[5] & 0x0F) != 9) return(NULL);           // control READ_BL_LEN - must be "9" on SDHC-/SDXC-cards
            FFSp_sshift = 0;                                       // code-compatibility -> no shift needed
            FFS_values.sectorsize = 0x0001UL << 9;                 // set BytsPerSec fix
            c_size = ((U32)(FFSp_data[7] & 0x3F) << 16) | ((U32)FFSp_data[8] << 8) | (FFSp_data[9]);
#ifdef MMC_EXT_CSD_CHECK
            if(MMCHandle_HsSD() == FFS_NO_ERR) {
                MMC_uSpeed  = FFSPort_MMC_SetBR(50000000);         // set max-speed in Hz and return used-speed
 #ifdef FFS_MMC_ADD_INFO
                FFS_values.mSpeed = 50000000;
                FFS_values.Speed  = MMC_uSpeed;
 #endif
            }
#endif
            MMC_Nac = (MMC_uSpeed / 10) / 8;                       // set Nac fix to 100ms (without code-cycles)
            MMC_Nbs = (MMC_Nac * 25) / 10;                         // set Nbs fix to 250ms
            if(c_size > 0x00FFFF) {                                // is bigger 32GB, its a SDXC-card (see SD 3.00)
                FFSp_ver = FFSp_MARK_SDXC;                         // currently we dont double-check SDXC using SCR-register (ACMD51)
                MMC_Nbs *= 2;                                      // set Nbs fix to 500ms
            }
            FFS_values.maxsectors = (c_size + 1) << 10;            // get MaxSectors -> mcap=(csize+1)*512k -> msec=mcap/BytsPerSec(fix)
            break;
        case FFSp_MARK_HDMMC:                              // ****************** high density MMC-cards *****************
            FFSp_sshift = 1;                                       // mark as invalid for HD-MMC (for a following check later)
#ifdef MMC_EXT_CSD_CHECK
            c_size      = ((U16)(FFSp_data[6] & 0x03) << 10) | ((U16)FFSp_data[7] << 2) | (FFSp_data[8] >> 6);
            c_size_mult = 0x0001 << (2 + (((FFSp_data[9] & 0x03) << 1) | (FFSp_data[10] >> 7)));
            hs_speed = MMCHandle_ExtCsd(FFSp_ver, MMC_uSpeed, c_size, c_size_mult); 
            if(hs_speed != 0) {                                    // if EXT_CSD supported and a new speed set -> we have to recalculate the timings
                MMC_uSpeed = hs_speed;
 #ifdef FFS_MMC_ADD_INFO
                FFS_values.Speed = MMC_uSpeed;
 #endif
                if(FFSp_sshift != 0) return(NULL);                 // no valid HD-MMC marks in EXT_CSD
                for(s_div = 1000, i = 7 - (FFSp_data[1] & 0x07); i > 0; s_div *= 10, i--);    // for: 1 / (TAAC_tu*10)
                hs_speed *= (U32)(MMC_m[((FFSp_data[1] >> 3) & 0x0F) - 1]);                   // as:  (TAAC_tv*10) * Fop
                MMC_Nac   = (10UL * (hs_speed / s_div) + 100UL * (U32)(FFSp_data[2])) / 8;    // 10 * ( ((TAAC_tv*10) * Fop) / (TAAC_tu*10) + 100 * NSAC) / 8
                MMC_Nbs   = MMC_Nac * (1UL << ((FFSp_data[12] >> 2) & 0x07));                 // Nac * R2W_factor
                i = MMCReadBlock(MMC_SEND_EXTCSD, 0, (U08 OS_HUGE *)FFSp_exCSD, 512, 1);      // read EXT_CSD again for resync card-internally
            } else return(NULL);                                                              // not MMC4.x or EXT_CSD not supported
            break;
#else
            // !!! here in Germany I can't get any HD-MMC cards, so actual this code does not support HD-MMC cards !!!
            // what is todo: - read extended-CSD
            //               - check EXT_CSD_REV and CARD_TYPE
            //               - read maxsectors = SEC_COUNT
            //               - set clock (normal /highspeed) and recalculate the timings
            return(NULL); 
            //lint -unreachable
//            break;
#endif
        default:                                           // ***** unknown type of MMC/SD-card *****
            return(NULL);
            //lint -unreachable
//            break;
    }
#ifdef FFS_MMC_ADD_INFO
    FFS_values.sectorsize_org = FFS_values.sectorsize;
    FFS_values.maxsectors_org = FFS_values.maxsectors;
    FFS_values.Nac            = MMC_Nac;
    FFS_values.Nbs            = MMC_Nbs;
    FFS_values.Version        = FFSp_ver;
#endif
    if(FFS_values.sectorsize != 512) {                     // if (actual) blocks of card greater 512-bytes (never on HD-MMC- and SDHC/SDXC-cards)
        i = MMCWriteCMD(MMC_SET_BLOCKLEN, 512, 1);         // set blocklength of transfers to 512 to be shure (all cards must support this value)
        if(i == FFS_NO_ERR) {
            FFS_values.maxsectors *= (FFS_values.sectorsize / 512);
            FFS_values.sectorsize  = 512;                  // recalculate maxsectors, set sectorsize
            FFSp_sshift            = 9;                    // and set shift manually (possible only on none HD-MMC- and SDHC/SDXC-cards)
        }
    }
    return(&FFS_values);                                   // return the card-size infos
}

/*
************************************************************
*            read a hole sector from the MMC/SD
************************************************************
*/
U08 FFSPort_ReadSector(U32 sector, U08 OS_HUGE *buff)
{
    U08 res;

    res = FFSPort_MediaDetect();
	if(res != FFS_NO_ERR) return(res);                 // media present ?
    res = MMCReadBlock(MMC_READ_SINGLE_BLOCK, sector << FFSp_sshift, buff, FFS_values.sectorsize, 0);
    if(res != FFS_NO_ERR) return(MMCReadStatus(res));      // read a hole sector and ...
    return(FFS_NO_ERR);                                    // ... read status if was an error
}

/*
************************************************************
*            write a hole sector to the MMC/SD
************************************************************
*/
U08 FFSPort_WriteSector(U32 sector, U08 OS_HUGE *buff)
{
    U32 i;
    U08 res;

    res = FFSPort_MediaDetect();
	if(res != FFS_NO_ERR) return(res);                 // media present ?
    if(FFSPort_MMC_WP()) return(FFS_WR_PROTECT);           // device is write protect
    res = MMCWriteCMD(MMC_WRITE_SINGLE_BLOCK, sector << FFSp_sshift, 0);
    if(res != FFS_NO_ERR) {
        FFSPort_MMC_CS_OFF; return(MMCReadStatus(res));    // cmd24 R1-error -> WriteProtect ?
    }
    FFSPort_MMC_Send(0xFF);                                // wait "Nwr" in front of wr-data
    FFSPort_MMC_Send(MMC_STARTBLOCK_WRITE);                // send startbyte
#ifdef USE_MMC_DMA
    FFSPort_MMC_TxBlock(buff, FFS_values.sectorsize);      // write datablock via DMA to MMC
#else
    for(i = 0; i < FFS_values.sectorsize; i++) {
        FFSPort_MMC_Send(buff[i]);                         // send datablock to MMC
    }
#endif
    FFSPort_MMC_Send(0xFF); FFSPort_MMC_Send(0xFF);        // write dummy CRC16 to MMC
    res = FFSPort_MMC_Send(0xFF);                          // get data-response (no "Nxx")
    switch(res & MMC_DR_MASK) {                            // mask data-response code
        case MMC_DR_REJECT_WRITE_ERROR:                    // ** data rejected due to a write error
            FFSPort_MMC_CS_OFF;                            //    disable MMC-interface
            return(MMCReadStatus(res));                    //    read status & return the error
            //lint -unreachable
//            break;
        case MMC_DR_ACCEPT:                                // ** data accepted
            i = 0;                                         //    wait "Nbusy" while busy
            while((FFSPort_MMC_Send(0xFF) != 0xFF) && (i < MMC_Nbs)) i++;
            if(i < MMC_Nbs) break;                         //    if error - too long busy
            //lint -fallthrough
        case MMC_DR_REJECT_CRC:                            // ** data rejected due to a CRC error
        default:
            FFSPort_MMC_CS_OFF;                            //    disable MMC-interface
            return(FFS_PORT_ERR);                          //    error
            //lint -unreachable
//            break;
    }
    FFSPort_MMC_CS_OFF;                                    // disable MMC-interface
    return(FFS_NO_ERR);                                    // no error
}

/*
************************************************************
*       read a count of sectors from the MMC/SD
************************************************************
*/
U08 FFSPort_ReadMultipleSectors(U32 sector, U08 OS_HUGE *buff, U16 cnt)
{
    U32 i, s;
    U08 res;

    res = FFSPort_MediaDetect();
    if(res != FFS_NO_ERR) return(res);                     // media present ?
    res = MMCWriteCMD(MMC_READ_MULTIPLE_BLOCK, sector << FFSp_sshift, 0);
    if(res != FFS_NO_ERR) {                                // wrong response! ..
        FFSPort_MMC_CS_OFF;                                // .. disable MMC-interface ...
        return(MMCReadStatus(res));                        // ... read status & return the error
    }
    s   = 0;
    res = FFS_NO_ERR;
    while((s < cnt) && (res == FFS_NO_ERR)) {
        i = 0;
        do {
            res = FFSPort_MMC_Send(0xFF); i++;             // wait "Nac"/"Ncx" for startbyte (0xFE)
        } while((res == 0xFF) && (i < MMC_Nac));
        if(i >= MMC_Nac) {                                 // startbyte received ? ..
            FFSPort_MMC_CS_OFF;                            // .. disable MMC-interface ...
            return(MMCReadStatus(res));                    // ... read status & return the error
        }
#ifdef USE_MMC_DMA
        res = FFSPort_MMC_RxBlock((U08 OS_HUGE *)(&buff[s * FFS_values.sectorsize]), FFS_values.sectorsize);  //   - read data via DMA
#else
        res = FFS_NO_ERR;
        for(i = 0; i < FFS_values.sectorsize; i++) {
            buff[(s * FFS_values.sectorsize) + i] = FFSPort_MMC_Send(0xFF);   //   - read data
        }
#endif
        FFSPort_MMC_Send(0xFF); FFSPort_MMC_Send(0xFF);    // read 2 bytes CRC16 (not used)
        s++;
    }
    MMCWriteCMD(MMC_STOP_TRANSMISSION, 0, 1);
    return(res);
}

/*
************************************************************
*         write a count of sectors to the MMC/SD
************************************************************
*/
U08 FFSPort_WriteMultipleSectors(U32 sector, U08 OS_HUGE *buff, U16 cnt)
{
    U32 i, s;
    U08 res;

    res = FFSPort_MediaDetect();
    if(res != FFS_NO_ERR) return(res);                     // media present ?
    if(FFSPort_MMC_WP()) return(FFS_WR_PROTECT);           // device is write protect
    res = MMCWriteCMD(MMC_WRITE_MULTIPLE_BLOCK, sector << FFSp_sshift, 0);
    if(res != FFS_NO_ERR) {                                // wrong response! ..
        FFSPort_MMC_CS_OFF;                                // .. disable MMC-interface ...
        return(MMCReadStatus(res));                        // ... read status & return the error
    }
    s   = 0;
    res = FFS_NO_ERR;
    while((s < cnt) && (res == FFS_NO_ERR)) {
        FFSPort_MMC_Send(0xFF);                            // wait "Nwr" in front of wr-data
        FFSPort_MMC_Send(MMC_STARTBLOCK_MWRITE);           // send startbyte
#ifdef USE_MMC_DMA
        FFSPort_MMC_TxBlock((U08 OS_HUGE *)(&buff[s * FFS_values.sectorsize]), FFS_values.sectorsize);  // write datablock via DMA to MMC
#else
        for(i = 0; i < FFS_values.sectorsize; i++) {
            FFSPort_MMC_Send(buff[(s * FFS_values.sectorsize) + i]);  // send datablock to MMC
        }
#endif
        FFSPort_MMC_Send(0xFF); FFSPort_MMC_Send(0xFF);    // write dummy CRC16 to MMC
        res = FFSPort_MMC_Send(0xFF);                      // get data-response (no "Nxx")
        if((res & MMC_DR_MASK) == MMC_DR_ACCEPT) {         // if data accepted
            i = 0;                                         // wait "Nbusy" while busy
            while((FFSPort_MMC_Send(0xFF) != 0xFF) && (i < MMC_Nbs)) i++;
            if(i < MMC_Nbs) res = FFS_NO_ERR;              // if error - too long busy
        } else
            res = MMCReadStatus(res);                      // read status & return the error
        s++;
    }
    FFSPort_MMC_Send(MMC_STOPTRAN_WRITE);
    FFSPort_MMC_Send(0xFF);                                // skip stuff-byte
    i = 0;                                                 // wait "Nbusy" while busy
    while((FFSPort_MMC_Send(0xFF) != 0xFF) && (i < MMC_Nbs)) i++;
    if(i >= MMC_Nbs) res = FFS_PORT_ERR;                   // if error - too long busy
    FFSPort_MMC_CS_OFF;                                    // disable MMC-interface
    return(res);
}

/************************** END ***************************/
