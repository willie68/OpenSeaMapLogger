/***********************************************************
*       a FREE MMC/SD-interface to SPI-slot of LPC17xx     *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_MMC.c                       *
*                   MMC/SD TO SPI PORT                     *
************************************************************
*      - code generation            Frank Goetze   11/2011 *
***********************************************************/

#include "../../../inc/MMC/LPC17xx/FFSPort_SPI.h"

/****************** constant variables ********************/
#define CPU_CRISTAL_CLK  12000000UL                        // processor crystal-clock in Hz
OS_CONST U08 OS_ROMDATA SPI_c[] = { 4, 1, 2, 8 };

/*
************************************************************
*          set max possible baudrate and return this
************************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk)
{
    U32 s_clksrc;
    U08 d;

    s_clksrc = CPU_CRISTAL_CLK;                                        // set start-clk (cristal-clk)
    if((LPC_SC->PLL0STAT & (3 << 24)) == (3 << 24)) {                  // if PLL is enabled & connected
        while(!(LPC_SC->PLL0STAT & (1 << 26)));                        // be shure PLL is locked
        s_clksrc /= (((LPC_SC->PLL0STAT & 0x00FF0000) >> 16) + 1);     // div clk with Pre-dividier NSEL0 + 1       - (defined at startup)
        s_clksrc *= (2 * ((LPC_SC->PLL0STAT & 0x00007FFF) + 1));       // mul clk with PLL-multiplier 2*(MSEL0 + 1) - (defined at startup)
    }
    s_clksrc /= ((LPC_SC->CCLKCFG & 0xFF) + 1);                        // div clk with CPU-dividier CCLKSEL + 1
    s_clksrc /= SPI_c[(LPC_SC->PCLKSEL0 >> 20) & 3];                   // div clk with PCLK-dividier PCLK_SSP1 (coded)
    s_clksrc /= (((LPC_SSP1->CR0 >> 8) & 0xFF) + 1);                   // div clk with serial-clk-rate SSP1_SCR + 1 
    d = 1;
    while((maxclk < (s_clksrc / (2 * d))) && (d < 0x7F)) d++;          // search lowest clk-div for SPI-speed (highest possible SPI-speed)
    LPC_SSP1->CPSR = 2 * d;                                            // set SSP-div and return the used SPI-speed in Hz
    return(s_clksrc / (2 * d));                                        // !!! since SSP_CPSR can only be an even-value ...
}                                                                      // ... you get not really alltimes the highest possible speed !!!

/*
************************************************************
*            write a char and read one back
************************************************************
*/
U08 FFSPort_MMC_Send(U08 w)
{
    while(!(LPC_SSP1->SR & 0x00000001U));                   // wait up to tx-empty
    LPC_SSP1->DR = w;                                       // write char and send
    while(!(LPC_SSP1->SR & 0x00000004U));                   // wait up to rx-not_empty (char received)
    return((U08)LPC_SSP1->DR);                              // return received char
}
	 
/*
************************************************************
*              reinitialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_ReInit(void)
{
    LPC_SSP1->CPSR = 0x000000FEU;                          // prescaler use at startup PCLK / 254
    LPC_SSP1->CR0  = 0x000000C7U;                          // div result of prescaler by 1 & CPHA=1 & CPOL=1 & SPI-format & 8-bit
    LPC_SSP1->CR1  = 0x00000002U;                          // SSP as SPI - enable as master
    FFSPort_MMC_SetBR(400000);                             // set SPI-clk to max 400kHz as startup (should never be > 400kHz, says MMC)
    return(0);                                             // return actual alltimes ok.
}

/*
************************************************************
*              initialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_Init(void)
{
    LPC_PINCON->PINSEL0        = 0x000A8000U;              // P0.7 as SCK1, P0.8 as MISO1, P0.9 as MOSI1, P0.6 as SSEL1 manual-GPIO
    LPC_PINCON->PINMODE0       = 0x000A8000U;              // SCK1, MISO1, MOSI1 no resistors - SSEL1 pull-up
    LPC_PINCON->PINSEL1        = 0x00000000U;              // P0.18 as CD, P0.21 as WP - both GPIO
    LPC_PINCON->PINMODE1       = 0x00000000U;              // CD & WP pull-up
    LPC_GPIO0->FIODIR         &= ((1 << 18) | (1 << 21));  // CD & WP as input	
    LPC_GPIO0->FIODIR         |= (1 << 6);                 // SSEL1 as output	
    LPC_GPIO0->FIOMASK        &= ~((1 << 6) | (1 << 18) | (1 << 21));  // SSEL1 open for writing, CD & WP open for reading (set 0 in mask)	
    return(FFSPort_MMC_ReInit());
}

