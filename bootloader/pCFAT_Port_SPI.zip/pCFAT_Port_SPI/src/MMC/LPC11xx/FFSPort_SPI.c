/***********************************************************
*       a FREE MMC/SD-interface to SPI-slot of LPC11xx     *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_MMC.c                       *
*                   MMC/SD TO SPI PORT                     *
************************************************************
*      - code generation            Frank Goetze   11/2011 *
***********************************************************/

#include "../../../inc/MMC/LPC11xx/FFSPort_SPI.h"

/****************** constant variables ********************/
#define CPU_CRISTAL_CLK  12000000UL                        // processor crystal-clock in Hz

/*
************************************************************
*          set max possible baudrate and return this
************************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk)
{
    U32 s_clksrc;
    U08 d;

    s_clksrc = CPU_CRISTAL_CLK;                                        // set start-clk (cristal-clk)
    if((LPC_SYSCON->MAINCLKSEL & 3) == 3) {                            // if PLL is enabled
        while(!(LPC_SYSCON->SYSPLLSTAT & 1));                          // be shure PLL is locked
        s_clksrc *= ((LPC_SYSCON->SYSPLLCTRL & 0x1F) + 1);             // mul clk with PLL-multiplier (defined at startup)
    }
    s_clksrc /= (1 << ((LPC_SYSCON->SYSPLLCTRL & 0x60) >> 5));         // div clk with Post-dividier  (defined at startup)
    d = 1;
    while(((s_clksrc / d) > maxclk) && (d < 256)) d++;                 // search lowest clk-div for SPI-speed (highest possible SPI-speed)
    LPC_SSP0->CPSR = d;                                                // set SSP-div and return the used SPI-speed in Hz
    return(s_clksrc / d);                                              
}

/*
************************************************************
*            write a char and read one back
************************************************************
*/
U08 FFSPort_MMC_Send(U08 w)
{
    while(!(LPC_SSP0->SR & 0x00000001U));                   // wait up to tx-empty
    LPC_SSP0->DR = w;                                       // write char and send
    while(!(LPC_SSP0->SR & 0x00000004U));                   // wait up to rx-not_empty (char received)
    return((U08)LPC_SSP0->DR);                              // return received char
}


/*
************************************************************
*              reinitialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_ReInit(void)
{
    LPC_SSP0->CPSR = 0x000000FEU;                          // prescaler use at startup PCLK / 254
    LPC_SSP0->CR0  = 0x000000C7U;                          // div result of prescaler by 1 & CPHA=1 & CPOL=1 & SPI-format & 8-bit
    LPC_SSP0->CR1  = 0x00000002U;                          // SSP as SPI - enable as master
    FFSPort_MMC_SetBR(400000);                             // set SPI-clk to max 400kHz as startup (should never be > 400kHz, says MMC)
    return(0);                                             // return actual alltimes ok.
}

/*
************************************************************
*              initialise the SPI-port
************************************************************
*/
U08 FFSPort_MMC_Init(void)
{
    LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 6);                 // clock GPIO
    LPC_SYSCON->PRESETCTRL    |= 1;                        // preset clock
    LPC_IOCON->PIO0_6          = 0x00000008U;              // P0.6 as WP (GPIO) pull-up
    LPC_IOCON->PIO0_7          = 0x00000008U;              // P0.7 as CD (GPIO) pull-up
    LPC_GPIO0->DIR            &= ~(3 << 6);                // ... as input	
    LPC_IOCON->PIO0_2          = 0x00000008U;              // P0.2 (manual SSEL0) pull-up
    LPC_GPIO0->DIR            |= (1 << 2);                 // ... as output	
    LPC_IOCON->PIO0_8          = 0x000000C1U;              // P0.8 as MISO0 no resistors
    LPC_IOCON->PIO0_9          = 0x000000C1U;              // P0.9 as MOSI0 no resistors
    LPC_IOCON->PIO2_11         = 0x000000C1U;              // P2.11 as SCK0 no resistors
//    LPC_IOCON->SCK_LOC         = 0x00000001U;              // SCK0 to P2.11
    LPC_SYSCON->SYSAHBCLKCTRL |= (1 << 11);                // clock SSP0/SPI0
    LPC_SYSCON->PRESETCTRL    |= 1;                        // preset clock
    return(FFSPort_MMC_ReInit());
}

