/***********************************************************
*     a FREE MMC/SD-interface to SPI-slot of AT91SAM7xxx   *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_SPI.c                       *
*                 SPI-PORT DECLARATIONS                    *
***********************************************************/
#define MMC_AT91SAM7xxx

//#define MMC_AT91SAM7Sxx                     // select used sub-version of SAM7xxx
//#define MMC_AT91SAM7XCxx
#define MMC_AT91SAM7SExx

#define USE_MMC_DMA                         // use the DMA mode

#include "../../../../inc/OS_Def_AT91SAM7xxx.h"

#ifndef AT91SAM7xxx_REGS
 #define REG32  (volatile U32 *)
 typedef volatile U32 AT91_REG;             // all registers are correct 32bit aligned
 typedef struct _AT91S_A32 {
    AT91_REG     s[32];                     // Source Mode Register & Source Vector Register
 } *AT91S_A32;
 typedef struct _AT91S_A04 {
    AT91_REG     s[4];                      // Endpoint Control and Status Register & Endpoint FIFO Data Register
 } *AT91S_A04;
 #define AT91S_SPI_BASE        (0xFFFE0000U)
 #define AT91S_SPI_CR          (*(REG32 (AT91S_SPI_BASE + 0x00)))      // Control Register
 #define AT91S_SPI_CR_EN       0x00000001U                             // (CR) SPI enable
 #define AT91S_SPI_CR_DIS      0x00000002U                             // (CR) SPI disable
 #define AT91S_SPI_CR_SWRST    0x00000080U                             // (CR) Software Reset
 #define AT91S_SPI_MR          (*(REG32 (AT91S_SPI_BASE + 0x04)))      // Mode Register
 #define AT91S_SPI_MR_MSTR     0x00000001U                             // (MR) set as master
 #define AT91S_SPI_MR_FDIV     0x00000008U                             // (MR) Clock Selection
 #define AT91S_SPI_MR_MODFDIS  0x00000010U                             // (MR) Mode Fault Detection disable
 #define AT91S_SPI_RDR         (*(REG32 (AT91S_SPI_BASE + 0x08)))      // Receive Data Register
 #define AT91S_SPI_TDR         (*(REG32 (AT91S_SPI_BASE + 0x0C)))      // Transmit Data Register
 #define AT91S_SPI_SR          (*(REG32 (AT91S_SPI_BASE + 0x10)))      // Status Register
 #define AT91S_SPI_SR_RDRF     0x00000001U                             // (SR) Receive Data Register Full
 #define AT91S_SPI_SR_TDRE     0x00000002U                             // (SR) Transmit Data Register Empty
 #define AT91S_SPI_SR_RXBUFF   0x00000040U                             // (SR) all Receive-cnt Registers Empty
 #define AT91S_SPI_SR_TXBUFE   0x00000080U                             // (SR) all Transmit-cnt Registers zero
 #define AT91S_SPI_SR_TXEMPTY  0x00000200U                             // (SR) all Transmit Registers Empty
 #define AT91S_SPI_CSR         ((AT91S_A04)(AT91S_SPI_BASE + 0x30))    // CSR [4] Chip Select Register
 #define AT91S_SPI_CSR_BITS_8  0x00000000U                             // (CSR)  8 Bits per transfer
 #define AT91S_SPI_CSR_CPOL    0x00000001U                             // (CSR) Clock Polarity One
 #define AT91S_SPI_CSR_SCBR_L  0x0000FF00U                             // (CSR) Serial Clock Baud Rate low
 #define AT91S_SPI_CSR_SCBR_M  0x0000FF00U                             // (CSR) Serial Clock Baud Rate mask
 #define AT91S_SPI_RPR         (*(REG32 (AT91S_SPI_BASE + 0x0100)))    // PDC Receive Pointer Register
 #define AT91S_SPI_RCR         (*(REG32 (AT91S_SPI_BASE + 0x0104)))    // PDC Receive Counter Register
 #define AT91S_SPI_TPR         (*(REG32 (AT91S_SPI_BASE + 0x0108)))    // PDC Transmit Pointer Register
 #define AT91S_SPI_TCR         (*(REG32 (AT91S_SPI_BASE + 0x010C)))    // PDC Transmit Counter Register
 #define AT91S_SPI_RNPR        (*(REG32 (AT91S_SPI_BASE + 0x0110)))    // PDC Receive Next Pointer Register
 #define AT91S_SPI_RNCR        (*(REG32 (AT91S_SPI_BASE + 0x0114)))    // PDC Receive Next Counter Register
 #define AT91S_SPI_TNPR        (*(REG32 (AT91S_SPI_BASE + 0x0118)))    // PDC Transmit Next Pointer Register
 #define AT91S_SPI_TNCR        (*(REG32 (AT91S_SPI_BASE + 0x011C)))    // PDC Transmit Next Counter Register
 #define AT91S_SPI_PTCR        (*(REG32 (AT91S_SPI_BASE + 0x0120)))    // PDC Transfer Control Register
 #define AT91S_SPI_PTSR        (*(REG32 (AT91S_SPI_BASE + 0x0124)))    // PDC Transfer Status Register

 #define AT91S_PDC_RXTEN       ((U32) 0x1 <<  0)                       // (PDC) Receiver Transfer Enable
 #define AT91S_PDC_RXTDIS      ((U32) 0x1 <<  1)                       // (PDC) Receiver Transfer Disable
 #define AT91S_PDC_TXTEN       ((U32) 0x1 <<  8)                       // (PDC) Transmitter Transfer Enable
 #define AT91S_PDC_TXTDIS      ((U32) 0x1 <<  9)                       // (PDC) Transmitter Transfer Disable

 #define AT91S_AIC_BASE        (0xFFFFF000)
 #define AT91S_AIC_SMR         ((AT91S_A32)(AT91S_AIC_BASE + 0x00))    // [32] Source Mode Register
 #define AT91S_AIC_SVR         ((AT91S_A32)(AT91S_AIC_BASE + 0x80))    // [32] Source Vector Register
 #define AT91S_AIC_IECR        (*(REG32 (AT91S_AIC_BASE + 0x120)))     // Interrupt Enable Command Register
 #define AT91S_AIC_IDCR        (*(REG32 (AT91S_AIC_BASE + 0x124)))     // Interrupt Disable Command Register
 #define AT91S_AIC_ICCR        (*(REG32 (AT91S_AIC_BASE + 0x128)))     // Interrupt Clear Command Register
 #define AT91S_AIC_EOICR       (*(REG32 (AT91S_AIC_BASE + 0x130)))     // End of Interrupt Command Register

 #define AT91S_PMC_BASE        (0xFFFFFC00U)
 #define AT91S_PMC_SCER        (*(REG32 (AT91S_PMC_BASE + 0x00)))      // System Clock Enable Register
 #define AT91S_PMC_PCER        (*(REG32 (AT91S_PMC_BASE + 0x10)))      // Peripheral Clock Enable Register
 #define AT91S_PMC_MCKR        (*(REG32 (AT91S_PMC_BASE + 0x30)))      // Master Clock Register
 #define AT91S_PMC_PLLCLK      0x00000003U                             // (PMC) Clock from PLL is selected
 #define AT91C_PMC_PRES_CLK_M  0x0000001CU                             // (PMC) Selected clock dividier-mask

 #define AT91S_CKGR_PLLR       (*(REG32 (AT91S_PMC_BASE + 0x2C)))      // PLL Register
 #define AT91S_CKGR_MUL        0x07FF0000U                             // (CKGR) PLL Multiplier
 #define AT91S_CKGR_DIV        0x000000FFU                             // (CKGR) Divider Selected

 #define AT91S_PIOA_BASE       (0xFFFFF400U)                           // only PIO-A in hardware
 #define AT91S_PIO_PER         (*(REG32 (AT91S_PIOA_BASE + 0x00)))     // PIO Enable Register
 #define AT91S_PIO_PDR         (*(REG32 (AT91S_PIOA_BASE + 0x04)))     // PIO Disable Register
 #define AT91S_PIO_PSR         (*(REG32 (AT91S_PIOA_BASE + 0x08)))     // PIO Status Register
 #define AT91S_PIO_OER         (*(REG32 (AT91S_PIOA_BASE + 0x10)))     // Output Enable Register
 #define AT91S_PIO_ODR         (*(REG32 (AT91S_PIOA_BASE + 0x14)))     // Output Disable Register
 #define AT91S_PIO_IFER        (*(REG32 (AT91S_PIOA_BASE + 0x20)))     // Input Filter Enable Register
 #define AT91S_PIO_IFDR        (*(REG32 (AT91S_PIOA_BASE + 0x24)))     // Input Filter Disable Register
 #define AT91S_PIO_SODR        (*(REG32 (AT91S_PIOA_BASE + 0x30)))     // Set Output Data Register
 #define AT91S_PIO_CODR        (*(REG32 (AT91S_PIOA_BASE + 0x34)))     // Clear Output Data Register
 #define AT91S_PIO_PDSR        (*(REG32 (AT91S_PIOA_BASE + 0x3C)))     // Pin Data Status Register
 #define AT91S_PIO_IER         (*(REG32 (AT91S_PIOA_BASE + 0x40)))     // Interrupt Enable Register
 #define AT91S_PIO_IDR         (*(REG32 (AT91S_PIOA_BASE + 0x44)))     // Interrupt Disable Register
 #define AT91S_PIO_IMR         (*(REG32 (AT91S_PIOA_BASE + 0x48)))     // Interrupt Mask Register
 #define AT91S_PIO_ISR         (*(REG32 (AT91S_PIOA_BASE + 0x4C)))     // Interrupt Status Register
 #define AT91S_PIO_PUDR        (*(REG32 (AT91S_PIOA_BASE + 0x60)))     // Pull-up Disable Register
 #define AT91S_PIO_PUER        (*(REG32 (AT91S_PIOA_BASE + 0x64)))     // Pull-up Enable Register
 #define AT91S_PIO_PUSR        (*(REG32 (AT91S_PIOA_BASE + 0x68)))     // Pull-up Status Register
 #define AT91S_PIO_ASR         (*(REG32 (AT91S_PIOA_BASE + 0x70)))     // Select A Register
 #define AT91S_PIO_BSR         (*(REG32 (AT91S_PIOA_BASE + 0x74)))     // Select B Register
 #define AT91S_PIO_OWER        (*(REG32 (AT91S_PIOA_BASE + 0xA0)))     // Output Write Enable Register
 #define AT91S_PIO_OWDR        (*(REG32 (AT91S_PIOA_BASE + 0xA4)))     // Output Write Disable Register
 #define AT91S_PIO_PA00        (1U << 0)                               // Pin Controlled by pin PA00
 #define AT91S_PIO_PA01        (1U << 1)                               // Pin Controlled by pin PA01
 #define AT91S_PIO_PA02        (1U << 2)                               // Pin Controlled by pin PA02
 #define AT91S_PIO_PA07        (1U << 7)                               // Pin Controlled by pin PA07
 #define AT91S_PIO_PA08        (1U << 8)                               // Pin Controlled by pin PA08
 #define AT91S_PIO_PA09        (1U << 9)                               // Pin Controlled by pin PA09
 #define AT91S_PIO_PA10        (1U << 10)                              // Pin Controlled by pin PA10
 #define AT91S_PIO_PA11        (1U << 11)                              // Pin Controlled by pin PA11
 #define AT91S_PIO_PA12        (1U << 12)                              // Pin Controlled by pin PA12
 #define AT91S_PIO_PA13        (1U << 13)                              // Pin Controlled by pin PA13
 #define AT91S_PIO_PA14        (1U << 14)                              // Pin Controlled by pin PA14
 #define AT91S_PIO_PA15        (1U << 15)                              // Pin Controlled by pin PA15
 #define AT91S_PIO_PA16        (1U << 16)                              // Pin Controlled by pin PA16
 #define AT91S_PIO_PA17        (1U << 17)                              // Pin Controlled by pin PA17
 #define AT91S_PIO_PA18        (1U << 18)                              // Pin Controlled by pin PA18
 #define AT91S_PIO_PA23        (1U << 23)                              // Pin Controlled by pin PA23
 #define AT91S_PIO_PA30        (1U << 30)                              // Pin Controlled by pin PA30
 #define AT91S_PIO_PA31        (1U << 31)                              // Pin Controlled by pin PA31

 #ifdef MMC_AT91SAM7XCxx
  #define AT91S_ID_SPI          4U                                      // Serial Peripheral Interface 0 ID
 #else
  #define AT91S_ID_SPI          5U                                      // Serial Peripheral Interface ID
 #endif
 #define AT91S_ID_PIO          2U                                      // Parallel IO Port ID
 #define PIOPort_INT_PRIO      1                                       // INT prio of PIO
 #define AT91S_AIC_SRCTYPE_INT_HIGHLEVEL_SENSITIVE  0x00000040U        // (AIC) Internal Sources Code Label High-Level Sensitive
#endif

#ifndef MMC_AT91SAM7Sxx
 #ifdef __IMAGECRAFT__
  void FFSPort_MMC_ISR(void);
 #else
  #ifdef __IAR_SYSTEMS_ICC__
   void FFSPort_MMC_ISR(void);
  #else
   #ifdef __KEIL__
    void FFSPort_MMC_ISR(void) __irq;
   #else
    #ifdef __GNUC__
     void FFSPort_MMC_ISR(void) __attribute__ ((interrupt ("IRQ")));
    #else
     #ifdef __CC_ARM
      void FFSPort_MMC_ISR(void);
     #else
      #error "unknown PIO-port"
     #endif
    #endif
   #endif
  #endif
 #endif
#endif

/*
************************************************************
*                      DEFINITIONS
************************************************************
*/
#ifdef MMC_AT91SAM7XCxx
 #define AT91S_SPI_NPCS0       AT91S_PIO_PA12                         // /CS0 PIO-pin
 #define AT91S_SPI_MISO        AT91S_PIO_PA16                         // MISO PIO-pin
 #define AT91S_SPI_MOSI        AT91S_PIO_PA17                         // MOSI PIO-pin
 #define AT91S_SPI_SPCK        AT91S_PIO_PA18                         // SCK  PIO-pin
 #define AT91S_SPI_CD          AT91S_PIO_PA13                         // CardDetect PIO-pin
 #define AT91S_SPI_WP          AT91S_PIO_PA15                         // WriteProtect PIO-pin
 #define FFSPort_MMC_WP()      (AT91S_PIO_PDSR & AT91S_PIO_PA15)      // PA15 as write-protect
#else
 #ifdef MMC_AT91SAM7SExx
  #define AT91S_SPI_NPCS0      AT91S_PIO_PA11                         // /CS0 PIO-pin
  #define AT91S_SPI_MISO       AT91S_PIO_PA12                         // MISO PIO-pin
  #define AT91S_SPI_MOSI       AT91S_PIO_PA13                         // MOSI PIO-pin
  #define AT91S_SPI_SPCK       AT91S_PIO_PA14                         // SCK  PIO-pin
  #define AT91S_SPI_CD         AT91S_PIO_PA01                         // CardDetect PIO-pin
  #define AT91S_SPI_WP         AT91S_PIO_PA02                         // WriteProtect PIO-pin
  #define FFSPort_MMC_WP()     (AT91S_PIO_PDSR & AT91S_PIO_PA02)      // PA02 as write-protect
 #else
  #ifdef MMC_AT91SAM7Sxx
   #define AT91S_SPI_NPCS0     AT91S_PIO_PA11                         // /CS0 PIO-pin
   #define AT91S_SPI_MISO      AT91S_PIO_PA12                         // MISO PIO-pin
   #define AT91S_SPI_MOSI      AT91S_PIO_PA13                         // MOSI PIO-pin
   #define AT91S_SPI_SPCK      AT91S_PIO_PA14                         // SCK  PIO-pin
   #define FFSPort_MMC_CD()    0                                      // no direct card-present check on AT91SAM7Sxx_DevMaster possible
   #define FFSPort_MMC_WP()    0                                      // no direct WP-check on AT91SAM7Sxx_DevMaster possible
  #else
   #error "unknown AT91SAM7__xx SPI-device!"
  #endif
 #endif
#endif
#define FFSPort_MMC_CS_OFF      AT91S_PIO_SODR = AT91S_SPI_NPCS0;
#define FFSPort_MMC_CS_ON       AT91S_PIO_CODR = AT91S_SPI_NPCS0;

/*
***********************************************************
*          MMC-Port of FFS/FAT FUNCTION PROTOTYPES
***********************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk);
U08 FFSPort_MMC_Send(U08 w);
U08 FFSPort_MMC_Init(void);
U08 FFSPort_MMC_ReInit(void);
#ifndef MMC_AT91SAM7Sxx
 U08 FFSPort_MMC_CD(void);
#endif
#ifdef USE_MMC_DMA
 U08 FFSPort_MMC_TxBlock(U08 OS_HUGE *block, U32 len);
 U08 FFSPort_MMC_RxBlock(U08 OS_HUGE *block, U32 len);
#endif

/************************* END ****************************/

