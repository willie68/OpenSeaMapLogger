/***********************************************************
*       a FREE MMC/SD-interface to SPI-slot of LPC214x     *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_SPI.c                       *
*                 SPI-PORT DECLARATIONS                    *
***********************************************************/
#define MMC_LPC214x

#include "../../../../inc/OS_Def_LPC214x.h"

#ifndef LPC214x_REGS
 #define REG32  (volatile U32 *)

 #define LPC_VPB_BASE            (0xE01FC100U)              // VPB base address
 #define LPC_VPB_DIV             (*(REG32 (LPC_VPB_BASE + 0x00)))

 #define LPC_SCB_BASE            (0xE01FC000U)              // PLL base address
 #define LPC_PLLSTAT             (*(REG32 (LPC_SCB_BASE + 0x88)))
 #define LPC_PCON                (*(REG32 (0xE01FC0C0)))
 #define LPC_PCONP               (*(REG32 (0xE01FC0C4)))
 #define LPC_PLL_PLLE            (1<<0)      /* PLL Enable */
 #define LPC_PLL_PLLC            (1<<1)      /* PLL Connect */
 #define LPC_PLL_MSEL            (0x1F<<0)   /* PLL Multiplier */
 #define LPC_PLL_PSEL            (0x03<<5)   /* PLL Divider */
 #define LPC_PLL_PLOCK           (1<<10)     /* PLL Lock Status */

 #define LPC_SSP_BASE            (0xE0068000U)              // SSP base address
 #define LPC_SSP_CR0             (*(REG32 (LPC_SSP_BASE + 0x00)))
 #define LPC_SSP_CR1             (*(REG32 (LPC_SSP_BASE + 0x04)))
 #define LPC_SSP_DR              (*(REG32 (LPC_SSP_BASE + 0x08)))
 #define LPC_SSP_SR              (*(REG32 (LPC_SSP_BASE + 0x0C)))
 #define LPC_SSP_CPSR            (*(REG32 (LPC_SSP_BASE + 0x10)))

 #define LPC_PIN_BASE            (0xE002C000U)              // PIN base address
 #define LPC_PINSEL1             (*(REG32 (LPC_PIN_BASE + 0x04)))
 #define LPC_PINSEL2             (*(REG32 (LPC_PIN_BASE + 0x14)))

 #define LPC_GPIO_BASE           (0xE0028000U)              // GPIO base address
 #define LPC_GPIO_0SET           (*(REG32 (LPC_GPIO_BASE + 0x04)))
 #define LPC_GPIO_0DIR           (*(REG32 (LPC_GPIO_BASE + 0x08)))
 #define LPC_GPIO_0CLR           (*(REG32 (LPC_GPIO_BASE + 0x0C)))
 #define LPC_GPIO_1PIN           (*(REG32 (LPC_GPIO_BASE + 0x10)))
#endif
/*
************************************************************
*                      DEFINITIONS
************************************************************
*/
#define FFSPort_MMC_CS_OFF    (LPC_GPIO_0SET = 0x00100000U) // set P0.20 high
#define FFSPort_MMC_CS_ON     (LPC_GPIO_0CLR = 0x00100000U) // set P0.20 low
#define FFSPort_MMC_CD()      (LPC_GPIO_1PIN & 0x02000000U) // P1.25 as card-detect -- only for none-INT based card-detect
#define FFSPort_MMC_WP()      (LPC_GPIO_1PIN & 0x01000000U) // P1.24 as write-protect

/*
***********************************************************
*          MMC-Port of FFS/FAT FUNCTION PROTOTYPES
***********************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk);
U08 FFSPort_MMC_Send(U08 w);
U08 FFSPort_MMC_Init(void);
U08 FFSPort_MMC_ReInit(void);
//U08 FFSPort_MMC_CD(void);                        // for INT based card-detect

/************************* END ****************************/
