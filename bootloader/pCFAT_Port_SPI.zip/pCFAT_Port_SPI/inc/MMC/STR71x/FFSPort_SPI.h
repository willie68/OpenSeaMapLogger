/***********************************************************
*       a FREE MMC/SD-interface to SPI-slot of STR71x      *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_SPI.c                       *
*                 SPI-PORT DECLARATIONS                    *
***********************************************************/
#define MMC_STR71x

#include "../../../../inc/OS_Def_STR71x.h"

#ifndef STR711_REGS
 #define STR_PRCCU_CFR    (*(volatile unsigned long *)0xA0000008)
 #define STR_PRCCU_CFR_CSU_CKSEL     0x1U
 #define STR_PRCCU_CFR_LOCK          0x2U
 #define STR_PRCCU_CFR_CK2_16        0x8U
 #define STR_PRCCU_CFR_DIV2          0x8000U

 #define STR_PRCCU_PLL1CR (*(volatile unsigned long *)0xA0000018)
 #define STR_PRCCU_PLL1CR_DX_MASK    0x7U
 #define STR_PRCCU_PLL1CR_MX_MASK    0x30U
 #define STR_PRCCU_PLL1CR_FREF_RANGE 0x40U
 #define STR_PRCCU_PLL1CR_FREEN      0x80U
 #define STR_PRCCU_PLL1CR_MX0        0x10U
 #define STR_PRCCU_PLL1CR_MX1        0x20U

 #define STR_PRCCU_PDIVR  (*(volatile unsigned long *)0xA0000044)
 #define STR_PRCCU_PDIVR_FACT1_MASK  0x3U
 #define STR_PRCCU_PDIVR_FACT2_MASK  0x300U

 #define STR_PRCCU_PWRCR  (*(volatile unsigned long *)0xA0000054)
 #define STR_PRCCU_PWRCR_VROK        0x1000U

 #define STR_BSPI1_CLK   (*(volatile unsigned short *)0xC000B010)
 #define STR_BSPI1_RXR   (*(volatile unsigned short *)0xC000B000)
 #define STR_BSPI1_TXR   (*(volatile unsigned short *)0xC000B004)
 #define STR_BSPI1_CSR1  (*(volatile unsigned short *)0xC000B008)
 #define STR_BSPI1_CSR2  (*(volatile unsigned short *)0xC000B00C)
 #define STR_BSPI1_CSR2_RFNE         0x8U
 #define STR_BSPI1_CSR2_TFE          0x40U

 #define STR_IOPORT0_PC0 (*(volatile unsigned short *)0xE0003000)
 #define STR_IOPORT0_PC1 (*(volatile unsigned short *)0xE0003004)
 #define STR_IOPORT0_PC2 (*(volatile unsigned short *)0xE0003008)
 #define STR_IOPORT0_PD  (*(volatile unsigned short *)0xE000300C)
 #define STR_IOPORT1_PC0 (*(volatile unsigned short *)0xE0004000)
 #define STR_IOPORT1_PC1 (*(volatile unsigned short *)0xE0004004)
 #define STR_IOPORT1_PC2 (*(volatile unsigned short *)0xE0004008)
 #define STR_IOPORT1_PD  (*(volatile unsigned short *)0xE000400C)
#endif
/*
************************************************************
*                      DEFINITIONS
************************************************************
*/
#define FFSPort_MMC_CS_OFF            STR_IOPORT0_PD |= 0x0100     // set P0.8 high (not P0.7 - see comment warning in c-file)
#define FFSPort_MMC_CS_ON             STR_IOPORT0_PD &=~0x0100     // set P0.8 low
#define FFSPort_MMC_CD()              (STR_IOPORT1_PD & 0x8000)    // P1.15 as card-detect -- only for none-INT based card-detect
#define FFSPort_MMC_WP()              (STR_IOPORT1_PD & 0x0400)    // P1.10 as write-protect

/*
***********************************************************
*          MMC-Port of FFS/FAT FUNCTION PROTOTYPES
***********************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk);
U08 FFSPort_MMC_Send(U08 w);
U08 FFSPort_MMC_Init(void);
U08 FFSPort_MMC_ReInit(void);
//U08 FFSPort_MMC_CD(void);                        // for INT based card-detect

/************************* END ****************************/
