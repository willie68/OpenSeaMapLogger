/***********************************************************
*        a FREE MMC/SD-interface to SPI-slot of STM32      *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_SPI.c                       *
*                 SPI-PORT DECLARATIONS                    *
***********************************************************/
#define MMC_STM32

#define MMC_MCBSTM32                                      // select Keil-board (or Olimex STM32-H103)
#define USE_MMC_DMA                                       // use the DMA mode


#include "../../../../inc/OS_Def_STM32.h"

#include "../../../../inc/STM32/library/inc/stm32f10x_rcc.h"
#include "../../../../inc/STM32/library/inc/stm32f10x_spi.h"
#include "../../../../inc/STM32/library/inc/stm32f10x_gpio.h"
#include "../../../../inc/STM32/library/inc/stm32f10x_dma.h"

/*
************************************************************
*                      DEFINITIONS
************************************************************
*/
#define SPI_      0                                        // define the used of 0=SPI1 or 1=SPI2 (for Keil-board must be "0")

#if (!SPI_)
 #define SPIx     SPI1                                     // **** SPI1 ****
 #define SPIx_bit GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7     // -> on SPI1 its PA5, PA6, PA7
 #define SPIx_Gx  GPIOA
 #define CS_bit   GPIO_Pin_4                               // -> on SPI1 its PA4
 #define CS_Gx    GPIOA
 #define DMA_rx   DMA_Channel2                             // DMA channel for receive SPI
 #define DMA_tx   DMA_Channel3                             // DMA channel for transmit SPI
 #define DMA_rf   DMA_FLAG_TC2
 #define DMA_tf   DMA_FLAG_TC3
 #ifdef MMC_MCBSTM32
  #define WP_bit   GPIO_Pin_8                              // -> on SPI1 we use PAx (simu), PA8 (WP not connected)
  #define CD_bit   GPIO_Pin_8
  #define WPCD_Gx  GPIOA
 #else
  #define WP_bit   GPIO_Pin_0                              // -> on SPI1 we use PC0, PC1
  #define CD_bit   GPIO_Pin_1 
  #define WPCD_Gx  GPIOC
 #endif
#else
 #define SPIx     SPI2                                     // **** SPI2 ****
 #define SPIx_bit GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15  // -> on SPI2 its PB13, PB14, PB15
 #define SPIx_Gx  GPIOB
 #define CS_bit   GPIO_Pin_12                              // -> on SPI2 its PB12
 #define CS_Gx    GPIOB
 #define WP_bit   GPIO_Pin_2                               // -> on SPI1 we use PC2, PC3
 #define CD_bit   GPIO_Pin_3
 #define WPCD_Gx  GPIOC
 #define DMA_rx   DMA_Channel4                             // DMA channel for receive SPI
 #define DMA_tx   DMA_Channel5                             // DMA channel for transmit SPI
 #define DMA_rf   DMA_FLAG_TC4
 #define DMA_tf   DMA_FLAG_TC5
#endif

#define FFSPort_MMC_CS_OFF    GPIO_SetBits(CS_Gx, CS_bit)             // set CS high
#define FFSPort_MMC_CS_ON     GPIO_ResetBits(CS_Gx, CS_bit)           // set CS low
#define FFSPort_MMC_CD()      GPIO_ReadInputDataBit(WPCD_Gx, CD_bit)  // card-detect -- only for none-INT based card-detect
#ifndef MMC_MCBSTM32
 #define FFSPort_MMC_WP()     GPIO_ReadInputDataBit(WPCD_Gx, WP_bit)  // write-protect
#else
 #define FFSPort_MMC_WP()     FFS_NO_ERR                              // default "not protected"
#endif

/*
***********************************************************
*          MMC-Port of FFS/FAT FUNCTION PROTOTYPES
***********************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk);
U08 FFSPort_MMC_Send(U08 w);
U08 FFSPort_MMC_Init(void);
U08 FFSPort_MMC_ReInit(void);
//U08 FFSPort_MMC_CD(void);                        // for INT based card-detect
#ifdef USE_MMC_DMA
 U08 FFSPort_MMC_TxBlock(U08 OS_HUGE *block, U32 len);
 U08 FFSPort_MMC_RxBlock(U08 OS_HUGE *block, U32 len);
#endif

/************************* END ****************************/
