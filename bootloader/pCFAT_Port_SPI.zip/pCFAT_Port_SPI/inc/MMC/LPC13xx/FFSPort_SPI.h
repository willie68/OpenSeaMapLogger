/***********************************************************
*       a FREE MMC/SD-interface to SPI-slot of LPC13xx     *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_SPI.c                       *
*                 SPI-PORT DECLARATIONS                    *
***********************************************************/
#define MMC_LPC13xx

#include "../../../../inc/OS_Def_LPC13xx.h"

#ifndef __LPC13xx_H__
 #warning "the register definitions are defined in LPC13xx.h from ARM CMSIS !"
#endif
/*
************************************************************
*                      DEFINITIONS
************************************************************
*/
#define FFSPort_MMC_CS_OFF    (LPC_GPIO0->DATA |=  (1 << 2))  // set P0.2 high
#define FFSPort_MMC_CS_ON     (LPC_GPIO0->DATA &= ~(1 << 2))  // set P0.2 low
#define FFSPort_MMC_CD()      (LPC_GPIO0->DATA & (1 << 7))    // P0.7 as card-detect -- only for none-INT based card-detect
#define FFSPort_MMC_WP()      (LPC_GPIO0->DATA & (1 << 6))    // P0.6 as write-protect

/*
***********************************************************
*          MMC-Port of FFS/FAT FUNCTION PROTOTYPES
***********************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk);
U08 FFSPort_MMC_Send(U08 w);
U08 FFSPort_MMC_Init(void);
U08 FFSPort_MMC_ReInit(void);
//U08 FFSPort_MMC_CD(void);                        // for INT based card-detect

/************************* END ****************************/
