/***********************************************************
*     a FREE MMC/SD-interface to SPI-slot of AT91SAM3xxx   *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                      FFSPort_SPI.c                       *
*                 SPI-PORT DECLARATIONS                    *
***********************************************************/
#define MMC_AT91SAM3xxx

#define USE_MMC_DMA                         // use the DMA mode

#include "../../../../inc/OS_Def_AT91SAM3xxx.h"


void FFSPort_MMC_ISR(void);

/*
************************************************************
*                      DEFINITIONS
************************************************************
*/
#ifdef MMC_AT91SAM3xxx
 #define MMC_SPI_NPCS0      PIO_PA11A_NPCS0                // /CS0 PIO-pin
 #define MMC_SPI_MISO       PIO_PA12A_MISO                 // MISO PIO-pin
 #define MMC_SPI_MOSI       PIO_PA13A_MOSI                 // MOSI PIO-pin
 #define MMC_SPI_SPCK       PIO_PA14A_SPCK                 // SCK  PIO-pin
 #define MMC_SPI_CD         PIO_PA9                        // CardDetect PIO-pin
 #define MMC_SPI_WP         PIO_PA10                       // WriteProtect PIO-pin
 #define FFSPort_MMC_WP()   (PIOA->PIO_PDSR & MMC_SPI_WP)  // PA10 as write-protect
#else
 #error "unknown AT91SAM3xxx SPI-device!"
#endif
#define FFSPort_MMC_CS_OFF  PIOA->PIO_SODR = MMC_SPI_NPCS0;
#define FFSPort_MMC_CS_ON   PIOA->PIO_CODR = MMC_SPI_NPCS0;

/*
***********************************************************
*          MMC-Port of FFS/FAT FUNCTION PROTOTYPES
***********************************************************
*/
U32 FFSPort_MMC_SetBR(U32 maxclk);
U08 FFSPort_MMC_Send(U08 w);
U08 FFSPort_MMC_Init(void);
U08 FFSPort_MMC_ReInit(void);
U08 FFSPort_MMC_CD(void);
#ifdef USE_MMC_DMA
 U08 FFSPort_MMC_TxBlock(U08 OS_HUGE *block, U32 len);
 U08 FFSPort_MMC_RxBlock(U08 OS_HUGE *block, U32 len);
#endif

/************************* END ****************************/

