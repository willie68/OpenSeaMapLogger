/***********************************************************
*     a FREE FFS/FAT Port to MMC/SD-slot using SPI-mode    *
*                                                          *
*          by  Frank Goetze  -  www.embedded-os.de         *
************************************************************
* Permission to use, copy, modify, and distribute this     *
* software in source and binary forms and its              *
* documentation for any purpose and without fee is hereby  *
* granted, provided that the above authors notice appear   *
* in all copies and that both that authors notice and this *
* permission notice appear in supporting documentation.    *
*                                                          *
* THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND   *
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT    *
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY    *
* AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.     *
* IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT,  *
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR             *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,    *
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF     *
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER *
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN        *
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING           *
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE   *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY *
* OF SUCH DAMAGE.                                          *
************************************************************
*                     FFS_Port_MMC.h                       *
*                  MMC PORT DECLARATIONS                   *
***********************************************************/
#ifndef FFS_MMC
 #define FFS_MMC

#define MMC_EXT_CSD_CHECK                                  // optional support for HS-MMC(MMCplus) and HD-MMC & HS-SD
#define FFS_MMC_ADD_INFO                                   // optional additional info collection into struct
#define FFS_ASSD_ADDON                                     // optional McEx/ASSD support for secure micro SD cards

/****************** low-level HW-adaption *****************/
// #include "ATMega128/FFSPort_SPI.h"                         // Atmel - ATMega128
// #include "AT91SAM7xxx/FFSPort_SPI.h"                       // Atmel - AT91SAM7..xx
 #include "AT91SAM3Sxx/FFSPort_SPI.h"                       // Atmel - AT91SAM3..xx
// #include "LPC11xx/FFSPort_SPI.h"                           // NXP - LPC1114
// #include "LPC13xx/FFSPort_SPI.h"                           // NXP - LPC1343
// #include "LPC17xx/FFSPort_SPI.h"                           // NXP - LPC1769
// #include "LPC214x/FFSPort_SPI.h"                           // NXP - LPC2148
// #include "STM32/FFSPort_SPI.h"                             // ST - STM32
// #include "STR71x/FFSPort_SPI.h"                            // ST - STR711


#ifdef OS_PACK_PRAGMA
 #pragma pack(1)
#endif
/***************** MMC-Sector configuration ***************/
#ifdef FFS_MMC_ADD_INFO
 #ifdef FFS_ASSD_ADDON
OS_PACKED typedef struct ffs_assd {
    U08      Type;                                         // type detected in "switch" grp no 2 response
    U08      SpecVer[5];                                   // spec version n.mm \0
    U16      CLsupport;                                    // CL support, A / B
    U08      PMsupport;                                    // protected memory support
    U16      AlgoSupport;                                  // PMs - Algo support, tDES / AES
    U16      EncSupport;                                   // PMs - Enc support,  tDES / AES
    U16      SecSys;                                       // security system,             tFlash / ASSD / Mc-EX (5C) -> ASSD 2.0 ...
    U32      Nsrl;                                         // Nsrl
    U32      Nswb;                                         // Nswb
    U32      Nwsb;                                         // Nwsb
    U32      Nexr;                                         // Nexr
    U32      Nexw;                                         // Nexw
} OS_PACKED_ATTR FFS_ASSD;
 #endif
#endif

OS_PACKED typedef struct ffs_size {
    U32      maxsectors;                                   // LBAs
    U32      sectorsize;                                   // sector-size in bytes
    U32      vp_id;                                        // vendor- & product-ID of memory (flash)
    U32      Speed;                                        // used speed
#ifdef FFS_MMC_ADD_INFO
    U32      mSpeed;                                       // max speed
    U32      maxsectors_org;                               // LBAs default by card
    U32      sectorsize_org;                               // sector-size default by card
    U32      Nac;                                          // Nac
    U32      Nbs;                                          // Nbs
    U08      Version;                                      // version (MMC/HDMMC/SD/SDHC/SDXC)
    U08      PName[7];                                     // product name \0
    U08      PRev[4];                                      // product revision n.m \0
    U32      PSerial;                                      // product serial 
    U08      PMdate[8];                                    // product manufacturing date m/j \0
    U08      SpecVer[5];                                   // spec version n.mm \0
    U08      SecVer[5];                                    // security version n.mm \0
 #ifdef FFS_ASSD_ADDON
    FFS_ASSD assd;                                         // sub-struct for McEx & ASSD
 #endif
#endif
    U08      flags;                                        // WriteProtect + 7bit unused
} OS_PACKED_ATTR FFS_SIZE;

#ifdef OS_PACK_PRAGMA
 #pragma pack()
#endif

/*
***********************************************************
*            return-codes definitions for FFS-Port
***********************************************************
*/
#define FFS_NO_ERR                       0                 // no errors
#define FFS_PORT_ERR                   100                 // error in FFS_Port
#define FFS_NO_MEDIA                   101                 // no media found
#define FFS_WR_PROTECT                 102                 // write-protect

/************* MMC/SD type marks (internal) ***************/
#define FFSp_MARK_MMC                 0x00                 // normal MMC-card
#define FFSp_MARK_HDMMC               0x01                 // high density, HDMMC-card
#define FFSp_MARK_SD                  0x10                 // standard SD-card
#define FFSp_MARK_SDHC                0x11                 // high capacity, SDHC-card
#define FFSp_MARK_SDXC                0x12                 // extended capacity, SDXC-card

/************** MMC/SD commands (SPI-mode) ****************/
#define MMC_GO_IDLE_STATE                0
#define MMC_SEND_OP_COND                 1
#define MMC_SWITCH                       6
#define MMC_SEND_EXTCSD                  8
#define MMC_SEND_CSD                     9
#define MMC_SEND_CID                    10
#define MMC_STOP_TRANSMISSION           12
#define MMC_SEND_STATUS                 13
#define MMC_SET_BLOCKLEN                16
#define MMC_READ_SINGLE_BLOCK           17
#define MMC_READ_MULTIPLE_BLOCK         18
#define MMC_SET_BLOCK_COUNT             23
#define MMC_WRITE_SINGLE_BLOCK          24
#define MMC_WRITE_MULTIPLE_BLOCK        25
#define MMC_PROGRAM_CSD                 27
#define MMC_SET_WRITE_PROT              28
#define MMC_CLR_WRITE_PROT              29
#define MMC_SEND_WRITE_PROT             30
#define MMC_TAG_ERASE_GROUP_START       35
#define MMC_TAG_ERASE_GROUP_END         36
#define MMC_ERASE                       38
#define MMC_LOCK_UNLOCK                 42
#define MMC_APP_CMD                     55
#define MMC_GEN_CMD                     56
#define MMC_READ_OCR                    58
#define MMC_CRC_ON_OFF                  59

#define SD_SEND_IF_COND                  8
#define SD_SEND_OP_COND_ACMD41          41
#define SD_SEND_CONFIG_REG_ACMD51       51

#ifdef FFS_ASSD_ADDON
 #define ASSD_READ_SEC_CMD              34
 #define ASSD_WRITE_SEC_CMD             35
 #define ASSD_SEND_PSI                  36
 #define ASSD_CONTROL_SYSTEM            37
 #define ASSD_DIRECT_SEC_READ           50
 #define ASSD_DIRECT_SEC_WRITE          57
#endif

/********** not used for backward compatibility ***********/
#define MMC_TAG_SECTOR_START            32
#define MMC_TAG_SECTOR_END              33
#define MMC_UNTAG_SECTOR                34
#define MMC_UNTAG_ERASE_GROUP           37

/************** R1 Response bit-defines *******************/
#define MMC_R1_BUSY                   0x80
#define MMC_R1_PARAMETER              0x40
#define MMC_R1_ADDRESS                0x20
#define MMC_R1_ERASE_SEQ              0x10
#define MMC_R1_COM_CRC                0x08
#define MMC_R1_ILLEGAL_COM            0x04
#define MMC_R1_ERASE_RESET            0x02
#define MMC_R1_IDLE_STATE             0x01

/********** R2 Response bit-defines (2. byte)**************/
#define MMC_R2_OUT_OF_RANGE           0x80
#define MMC_R2_ERASE_PARAM            0x40
#define MMC_R2_WP_VIOLATION           0x20
#define MMC_R2_ECC_FAIL               0x10
#define MMC_R2_CC_ERROR               0x08
#define MMC_R2_ERROR                  0x04
#define MMC_R2_WP_ERASE_SKIP          0x02
#define MMC_R2_CARD_LOCKED            0x01

/******************** Data tokens *************************/
#define MMC_STARTBLOCK_READ           0xFE
#define MMC_STARTBLOCK_WRITE          0xFE
#define MMC_STARTBLOCK_MWRITE         0xFC
#define MMC_STOPTRAN_WRITE            0xFD

/************** Data Error Token values *******************/
#define MMC_DE_MASK                   0x1F
#define MMC_DE_ERROR                  0x01
#define MMC_DE_CC_ERROR               0x02
#define MMC_DE_ECC_FAIL               0x04
#define MMC_DE_OUT_OF_RANGE           0x08
#define MMC_DE_CARD_LOCKED            0x10

/************* Data Response Token values *****************/
#define MMC_DR_MASK                   0x1F
#define MMC_DR_ACCEPT                 0x05
#define MMC_DR_REJECT_CRC             0x0B
#define MMC_DR_REJECT_WRITE_ERROR     0x0D

/*
***********************************************************
*               FFS-Port FUNCTION PROTOTYPES
***********************************************************
*/
U08       FFSPort_Init(void);
U08       FFSPort_MediaDetect(void);
FFS_SIZE *FFSPort_MediaInit(void);
U08       FFSPort_ReadSector(U32 sector, U08 OS_HUGE *buff);
U08       FFSPort_ReadMultipleSectors(U32 sector, U08 OS_HUGE *buff, U16 cnt);
U08       FFSPort_WriteSector(U32 sector, U08 OS_HUGE *buff);
U08       FFSPort_WriteMultipleSectors(U32 sector, U08 OS_HUGE *buff, U16 cnt);

#ifdef FFS_ASSD_ADDON
 U08      FFSPort_ASSD_SetMode(U08 mode);
 U16      FFSPort_ASSD_Reset(void);
 U16      FFSPort_ASSD_APDU(U08 *apdu, U16 len, U16 maxrlen);
#endif

/*********************************************************/

#endif
