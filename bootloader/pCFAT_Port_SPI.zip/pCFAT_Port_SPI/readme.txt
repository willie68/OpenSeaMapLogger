DE
-----------------------------------------------------------------------------------------
Anstatt der gelinkten "OS_Def_xxx.h" bitte die "OS_xxx.h" des pC/OS verwenden.

Das Port auf die AT91SAM7... Reihe zeigt ein Interrupt-basierendes Card-Detect, 
das auch den schnellen Wechsel der Karte erkennt und meldet. 
Dies kann auch bei den anderen Ports nachger�stet werden.


EN
-----------------------------------------------------------------------------------------
Instead of the linked "OS_Def_xxx.h" please use the "OS_xxx.h" of the pC/OS kernel.

The port to the AT91SAM7... productline shows a interrupt-based card-detect,
that can detect a possible fast change of the card and announce this.
This can be re-tooled also on the other ports.