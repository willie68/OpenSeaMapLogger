These sample sketches have been converted to binary format for bootloading from SD card.

blink.bin -- BlinkWithoutDelay sketch on pin13
fastblink.bin -- BlinkWIthoutDelay sketch on pin32 with faster blink
Blink2GPS.bin -- alternate blinking 2 LED's on the i2GPS
PTU.bin - Precision Timing Unit for i2GPS

Copy one of these to the SD card and rename it app.bin
