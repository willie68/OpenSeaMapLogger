#include <avr/io.h>
#include <string.h>
#include <avr/boot.h>
#include <avr/pgmspace.h>
#include <util/crc16.h>
#include "fat1216.h"

//#define USE_FLASH_LED
#define FLASH_LED_PORT PORTD
#define FLASH_LED_DDR DDRD
#define FLASH_LED_PIN PD4
#define FLASH_LED_POLARITY 1

#include <stdio.h>

typedef struct
{
	uint32_t dev_id;
	uint16_t app_version;
	uint16_t crc;
} bootldrinfo_t;


uint16_t startcluster;
uint16_t updatecluster; //is set when update is available
bootldrinfo_t current_bootldrinfo;

void (*app_start)(void);// = 0x0000;

static inline void check_file(void)
{
	//Check filesize
	app_start = (void(*)(void))0;
	if (filesize != FLASHEND - BOOTLDRSIZE + 1)
		return;

	bootldrinfo_t *file_bootldrinfo;
	fat1216_readfilesector(startcluster, (FLASHEND - BOOTLDRSIZE + 1) / 512 - 1);
	
	file_bootldrinfo =  (bootldrinfo_t*) (uint8_t*) (fat_buf + (FLASHEND - BOOTLDRSIZE - sizeof(bootldrinfo_t) + 1) % 512);
	
	//Check DEVID
	if (file_bootldrinfo->dev_id != DEVID)
		return;
		
	//Check application version
	if (file_bootldrinfo->app_version <= current_bootldrinfo.app_version)
		return;
		
	current_bootldrinfo.app_version = file_bootldrinfo->app_version;
	updatecluster = startcluster;
}


int main(void)
{
	uint16_t i;
	
	uint16_t filesector, j;
	uint16_t *lpword;
	#if (FLASHEND > 0xFFFF)
		uint32_t adr;
	#else
		uint16_t adr;
	#endif
	
	//LED On
	#ifdef USE_FLASH_LED
	FLASH_LED_DDR = 1<<FLASH_LED_PIN;
	#if !FLASH_LED_POLARITY
	FLASH_LED_PORT |= 1<<FLASH_LED_PIN;
	#endif
	#endif
	
	#if (FLASHEND > 0xFFFF)
		for (i=0; i<8; i++)
			((uint8_t *)&current_bootldrinfo)[i] = pgm_read_byte_far(FLASHEND - BOOTLDRSIZE - sizeof(bootldrinfo_t) + 1 + i);

//		((uint32_t *)(&current_bootldrinfo))[0] = pgm_read_dword_far( FLASHEND - BOOTLDRSIZE - sizeof(bootldrinfo_t) + 1 );
//		((uint32_t *)(&current_bootldrinfo))[1] = pgm_read_dword_far( FLASHEND - BOOTLDRSIZE - sizeof(bootldrinfo_t) + 1 + 4);
	#else
		memcpy_P(&current_bootldrinfo, (uint8_t*) FLASHEND - BOOTLDRSIZE - sizeof(bootldrinfo_t) + 1, sizeof(bootldrinfo_t));
	#endif
	
	if (current_bootldrinfo.app_version == 0xFFFF)
		current_bootldrinfo.app_version = 0; //application not flashed yet
		
	if (fat1216_init() == 0)
	{
		for (i=0; i<512; i++)
		{
			startcluster = fat1216_readRootDirEntry(i);

			if (startcluster == 0xFFFF)
				continue;
			
			check_file();
		}
		
		if (updatecluster)
		{
			for (filesector = 0; filesector < (FLASHEND - BOOTLDRSIZE + 1) / 512; filesector++)
			{
				#ifdef USE_FLASH_LED
				FLASH_LED_PORT ^= 1<<FLASH_LED_PIN;
				#endif
		
				lpword = (uint16_t*) fat_buf;
				fat1216_readfilesector(updatecluster, filesector);
				
				for (i=0; i<(512 / SPM_PAGESIZE); i++)
				{
					#if (FLASHEND > 0xFFFF)
						adr = (filesector * 512UL) + i * SPM_PAGESIZE;
					#else
						adr = (filesector * 512) + i * SPM_PAGESIZE;
					#endif
					boot_page_erase(adr);
					while (boot_rww_busy())
						boot_rww_enable();
			
					for (j=0; j<SPM_PAGESIZE; j+=2)
						boot_page_fill(adr + j, *lpword++);

					boot_page_write(adr);
					while (boot_rww_busy())
						boot_rww_enable();
					
				}
			}
	
			//LED on
			#ifdef USE_FLASH_LED
			#if FLASH_LED_POLARITY
			FLASH_LED_PORT &= ~(1<<FLASH_LED_PIN);
			#else
			FLASH_LED_PORT |= 1<<FLASH_LED_PIN;
			#endif
			#endif
		}
	}
	
	unsigned short flash_crc = 0xFFFF;
	
	for (adr=0; adr<FLASHEND - BOOTLDRSIZE + 1; adr++)
	#if (FLASHEND > 0xFFFF)
		flash_crc = _crc_ccitt_update(flash_crc, pgm_read_byte_far(adr));
	#else
		flash_crc = _crc_ccitt_update(flash_crc, pgm_read_byte(adr));
	#endif
	
	if (flash_crc == 0)
	{
		//Led off
		#ifdef USE_FLASH_LED
		FLASH_LED_DDR = 0x00;
		#endif
		app_start();
	}
	
	while (1);
}
