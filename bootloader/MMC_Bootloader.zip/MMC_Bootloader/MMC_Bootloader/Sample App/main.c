#include <avr/io.h>

typedef struct
{
	unsigned long dev_id;
	unsigned short app_version;
	unsigned short crc;
} bootldrinfo_t;

const bootldrinfo_t bootlodrinfo __attribute__ ((section (".bootldrinfo"))) = {DEVID, SWVERSIONMAJOR << 8 | SWVERSIONMINOR, 0x0000};


int main(void)
{
	volatile uint32_t d;
	uint8_t i = 0;
	
	DDRC = 0xFF;
	PORTC = 0xFF;
	
	for (;;)
	{
		for (d=0; d<60000; d++);
		PORTC = i--;
	}
}
