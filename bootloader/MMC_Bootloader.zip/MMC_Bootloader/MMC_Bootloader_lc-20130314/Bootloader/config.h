#ifndef CONFIG_H
#define CONFIG_H 1

#include <avr/io.h>

/* SD card socket connections */

#define SPI_PORT      	PORTB		/* SPI Connection port */
#define SPI_DDR       	DDRB		/* SPI Direction port */

#define SPI_SCK		5
#define SPI_MISO	4
#define SPI_MOSI	3

#define SD_CS_PORT	PORTB		/* CS (Card Select) pin */
#define SD_CS_DDR	DDRB
#define SD_CS_PIN	2


#define USE_FLASH_LED		0	/* 0 = no LED used */
#define FLASH_LED_PORT		PORTC
#define FLASH_LED_DDR 		DDRC
#define FLASH_LED_PIN 		4
#define FLASH_LED_POLARITY	1


#endif /* CONFIG_H */

