#include <avr/io.h>
#include <avr/boot.h>
#include <avr/pgmspace.h>
#include <util/crc16.h>
#include "fat1216.h"
#include "config.h"


#ifndef USE_FLASH_LED
 #define USE_FLASH_LED 0
#endif
#if USE_FLASH_LED
 #define FLASH_LED_ON()	 FLASH_LED_PORT = FLASH_LED_POLARITY ? FLASH_LED_PORT & ~(1<<FLASH_LED_PIN) \
							     : FLASH_LED_PORT |  (1<<FLASH_LED_PIN)
 #define FLASH_LED_OFF() FLASH_LED_PORT = FLASH_LED_POLARITY ? FLASH_LED_PORT |  (1<<FLASH_LED_PIN) \
							     : FLASH_LED_PORT & ~(1<<FLASH_LED_PIN)
 #define FLASH_LED_TOGGLE() FLASH_LED_PORT ^=  (1<<FLASH_LED_PIN)
#else
 #define FLASH_LED_ON()
 #define FLASH_LED_OFF()
 #define FLASH_LED_TOGGLE()
#endif


#define APPSIZE (FLASHEND - BOOTLDRSIZE + 1)
#define INFOSIZE (sizeof(bootldrinfo_t))

typedef struct {
	uint32_t dev_id;
	uint16_t app_version;
	uint16_t crc;
} bootldrinfo_t;

static uint16_t startcluster;
static uint16_t updatecluster; //is set when update is available
static bootldrinfo_t current_bootldrinfo;


static inline uint16_t crc_file(void) {
	uint16_t filesector;
	uint16_t flash_crc = 0xFFFF;

	for (filesector = 0; filesector < APPSIZE / 512; filesector++) {
		FLASH_LED_TOGGLE();

		fat1216_readfilesector(startcluster, filesector);

		for (int index = 0; index < 512; index++) {
			flash_crc = _crc_ccitt_update(flash_crc, fat_buf[index]);
		}
	}
	FLASH_LED_ON();

	return flash_crc; // result is ZERO when CRC is okay
}

static inline void check_file(void) {

	bootldrinfo_t *file_bootldrinfo;

	//Check filesize
	
	if (filesize != FLASHEND - BOOTLDRSIZE + 1)
		return;

	//Get last sector
	fat1216_readfilesector(startcluster, APPSIZE / 512 - 1);
	file_bootldrinfo =  (bootldrinfo_t*) (uint8_t*) (fat_buf + 512 - INFOSIZE);
	
	//Check DEVID
	if (file_bootldrinfo->dev_id != DEVID)
		return;
		
	//Check application version
	if (file_bootldrinfo->app_version <= current_bootldrinfo.app_version && 
	    file_bootldrinfo->app_version   != 0  &&
	    current_bootldrinfo.app_version != 0)
		return;
	
	// If development version in flash and in file, check for different crc
	if (current_bootldrinfo.app_version == 0 &&
	    file_bootldrinfo->app_version   == 0 &&
	    current_bootldrinfo.crc == file_bootldrinfo->crc)
	        return;

	// check CRC of file
	if(crc_file() != 0)
		return;
			
	current_bootldrinfo.app_version = file_bootldrinfo->app_version;
	updatecluster = startcluster;
}

static inline void flash_update(void) {

	uint16_t *lpword;
#if (FLASHEND > 0xFFFF)
	uint32_t adr;
#else
	uint16_t adr;
#endif

	adr = 0;
	for (int filesector = 0; filesector < APPSIZE / 512; filesector++) {

		FLASH_LED_TOGGLE();
		lpword = (uint16_t*) fat_buf;
		fat1216_readfilesector(updatecluster, filesector);
		
		for (unsigned int i = 0; i < (512/SPM_PAGESIZE); i++, adr += SPM_PAGESIZE) {
			
			boot_page_erase(adr);
			while (boot_rww_busy())
				boot_rww_enable();
	
			for (unsigned int j=0; j<SPM_PAGESIZE; j+=2)
				boot_page_fill(adr + j, *lpword++);

			boot_page_write(adr);
			while (boot_rww_busy())
				boot_rww_enable();
			
		}
	}
	FLASH_LED_ON();
}

void main(void) __attribute__ ((noreturn));
void main(void) {

	static void (*app_start)(void) = 0x0000;
	uint8_t rc;

	/* Disable watchdog timer */
#ifdef WDTCSR
	WDTCSR |= (1<<WDCE) | (1<<WDE);
	WDTCSR  = 0x00;
#elif defined WDTCR
 #ifndef WDCE
  #ifdef WDTOE
   #define WDCE WDTOE
  #endif
 #endif
 #ifdef WDCE
	WDTCR |= (1<<WDCE) | (1<<WDE);
	WDTCR  = 0x00;
 #else
	/* don't know, how to handle watchdog */
 #endif
#endif

#if USE_FLASH_LED
	FLASH_LED_ON();
	FLASH_LED_DDR |= (1<<FLASH_LED_PIN);
#endif

#if FLASHEND > 0xFFFF
	memcpy_PF(&current_bootldrinfo, (uint_farptr_t)APPSIZE - INFOSIZE, INFOSIZE);
#else
	memcpy_P (&current_bootldrinfo,    (uint8_t *) APPSIZE - INFOSIZE, INFOSIZE);
#endif

	if (current_bootldrinfo.app_version == 0xFFFF) {
			current_bootldrinfo.app_version = 0; //application not flashed yet
	}
	
	rc = fat1216_init();
	if (rc == 0) {
		for (uint16_t i = 0; i < 512; i++) {
			startcluster = fat1216_readRootDirEntry(i);

			if (startcluster == 0xFFFF)
				continue;

			check_file();
		}

		if (updatecluster)
			flash_update();
	}

#if USE_FLASH_LED
	FLASH_LED_DDR &= ~(1<<FLASH_LED_PIN);
#endif
	app_start();
	for (;;);
}
